class AppConfig {
  // API Configuration
  static const String baseUrl = 'https://api.fixit.com/v1';
  static const String apiVersion = 'v1';

  // Google Maps API Key
  static const String googleMapsApiKey = 'YOUR_GOOGLE_MAPS_API_KEY_HERE';

  // Stripe Configuration
  static const String stripePublishableKey = 'pk_test_YOUR_STRIPE_PUBLISHABLE_KEY_HERE';
  static const String stripeMerchantId = 'merchant.com.yourcompany.fixit';

  // App Information
  static const String appName = 'Fix It';
  static const String appVersion = '1.0.0';
  static const String supportEmail = 'support@fixit.com';
  static const String supportPhone = '+1-800-FIXIT-NOW';

  // Feature Flags
  static const bool enableGoogleMaps = true;
  static const bool enableStripePayments = true;
  static const bool enablePushNotifications = true;
  static const bool enableAnalytics = true;

  // Cache Configuration
  static const int cacheTimeoutMinutes = 30;
  static const int maxCachedItems = 100;

  // File Upload Configuration
  static const int maxFileSize = 10 * 1024 * 1024; // 10MB
  static const List<String> allowedImageTypes = ['jpg', 'jpeg', 'png', 'gif'];
  static const List<String> allowedDocumentTypes = ['pdf', 'doc', 'docx', 'txt'];

  // Location Configuration
  static const double defaultRadius = 25.0; // km
  static const double maxRadius = 100.0; // km

  // Booking Configuration
  static const int maxBookingDaysInAdvance = 90;
  static const int minBookingHoursInAdvance = 2;
  static const double urgentBookingMultiplier = 1.5;
  static const double platformFeePercentage = 0.05; // 5%
  static const double taxRate = 0.08; // 8%

  // UI Configuration
  static const int animationDurationMs = 300;
  static const double borderRadius = 12.0;
  static const double cardElevation = 2.0;

  // Development flags
  static const bool isDebugMode = true;
  static const bool enableLogging = true;
  static const bool mockApiCalls = false;
}

class ApiEndpoints {
  static const String auth = '/auth';
  static const String login = '$auth/login';
  static const String register = '$auth/register';
  static const String forgotPassword = '$auth/forgot-password';
  static const String refreshToken = '$auth/refresh';

  static const String services = '/services';
  static const String serviceDetails = '$services/{id}';
  static const String serviceCategories = '$services/categories';
  static const String searchServices = '$services/search';

  static const String providers = '/providers';
  static const String providerDetails = '$providers/{id}';
  static const String providerReviews = '$providers/{id}/reviews';
  static const String nearbyProviders = '$providers/nearby';
  static const String featuredProviders = '$providers/featured';
  static const String searchProviders = '$providers/search';

  static const String bookings = '/bookings';
  static const String createBooking = bookings;
  static const String bookingDetails = '$bookings/{id}';
  static const String cancelBooking = '$bookings/{id}/cancel';
  static const String rescheduleBooking = '$bookings/{id}/reschedule';
  static const String userBookings = '$bookings/user';

  static const String timeSlots = '/time-slots';
  static const String providerTimeSlots = '$providers/{id}/time-slots';

  static const String payments = '/payments';
  static const String processPayment = '$payments/process';
  static const String paymentMethods = '$payments/methods';

  static const String uploads = '/uploads';
  static const String uploadFile = uploads;
  static const String deleteFile = '$uploads/delete';
}

class ErrorMessages {
  static const String networkError = 'Network connection error. Please check your internet connection.';
  static const String serverError = 'Server error. Please try again later.';
  static const String authenticationError = 'Authentication failed. Please login again.';
  static const String validationError = 'Please check your input and try again.';
  static const String permissionDenied = 'Permission denied. Please grant the required permissions.';
  static const String locationError = 'Unable to get your location. Please check location settings.';
  static const String paymentError = 'Payment processing failed. Please try again.';
  static const String bookingError = 'Booking creation failed. Please try again.';
  static const String fileUploadError = 'File upload failed. Please try again.';
  static const String cacheError = 'Unable to load cached data.';
}

class SuccessMessages {
  static const String bookingCreated = 'Booking created successfully!';
  static const String bookingCancelled = 'Booking cancelled successfully.';
  static const String paymentProcessed = 'Payment processed successfully.';
  static const String profileUpdated = 'Profile updated successfully.';
  static const String fileUploaded = 'File uploaded successfully.';
  static const String passwordReset = 'Password reset email sent successfully.';
}
