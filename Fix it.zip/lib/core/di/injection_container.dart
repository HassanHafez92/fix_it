import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dartz/dartz.dart';
import '../../core/error/failures.dart';

// Features
import '../../features/auth/data/datasources/auth_local_data_source.dart';
import '../../features/auth/data/datasources/auth_firebase_data_source.dart';
import '../../features/auth/data/repositories/auth_repository_impl.dart';
import '../../features/auth/domain/repositories/auth_repository.dart';
import '../../features/auth/domain/usecases/sign_in_usecase.dart';
import '../../features/auth/domain/usecases/sign_up_usecase.dart';
import '../../features/auth/domain/usecases/sign_out_usecase.dart';
import '../../features/auth/domain/usecases/get_current_user_usecase.dart';
import '../../features/auth/domain/usecases/forgot_password_usecase.dart';
import '../../features/auth/domain/usecases/client_sign_up_usecase.dart';
import '../../features/auth/presentation/bloc/auth_bloc.dart';
import '../../features/auth/presentation/bloc/client_sign_up/client_sign_up_bloc.dart';

// Services Feature
import '../../features/services/data/datasources/service_remote_data_source.dart';
import '../../features/services/data/datasources/service_local_data_source.dart';
import '../../features/services/data/repositories/service_repository_impl.dart';
import '../../features/services/domain/repositories/service_repository.dart';
import '../../features/services/domain/usecases/get_services_usecase.dart';
import '../../features/services/domain/usecases/get_service_details_usecase.dart';
import '../../features/services/domain/usecases/get_services_by_category_usecase.dart';
import '../../features/services/domain/usecases/search_services_usecase.dart';
import '../../features/services/domain/usecases/get_categories_usecase.dart';
import '../../features/services/presentation/bloc/services_bloc.dart';
import '../../features/services/presentation/bloc/service_details_bloc.dart';

// Providers Feature
import '../../features/providers/data/datasources/provider_remote_data_source.dart';
import '../../features/providers/data/datasources/provider_local_data_source.dart';
import '../../features/providers/data/repositories/provider_repository_impl.dart';
import '../../features/providers/domain/repositories/provider_repository.dart';
import '../../features/providers/domain/usecases/search_providers_usecase.dart';
import '../../features/providers/domain/usecases/get_provider_details_usecase.dart';
import '../../features/providers/domain/usecases/get_provider_reviews_usecase.dart';
import '../../features/providers/domain/usecases/get_nearby_providers_usecase.dart';
import '../../features/providers/domain/usecases/get_featured_providers_usecase.dart';
import '../../features/providers/presentation/bloc/provider_search_bloc.dart';
import '../../features/providers/presentation/bloc/provider_details_bloc.dart';

// Booking Feature
import '../../features/booking/data/datasources/booking_remote_data_source.dart';
import '../../features/booking/data/datasources/booking_local_data_source.dart';
import '../../features/booking/data/repositories/booking_repository_impl.dart';
import '../../features/booking/domain/repositories/booking_repository.dart';
import '../../features/booking/domain/usecases/create_booking_usecase.dart';
import '../../features/booking/domain/usecases/get_available_time_slots_usecase.dart';
import '../../features/booking/domain/usecases/get_user_bookings_usecase.dart';
import '../../features/booking/domain/usecases/get_booking_details_usecase.dart';
import '../../features/booking/domain/usecases/cancel_booking_usecase.dart';
import '../../features/booking/presentation/bloc/create_booking_bloc.dart';
import '../../features/booking/presentation/bloc/bookings_bloc.dart';

// Payment Feature
import '../../features/booking/data/datasources/payment_remote_data_source.dart';
import '../../features/booking/data/datasources/payment_local_data_source.dart';
import '../../features/booking/data/repositories/payment_repository_impl.dart';
import '../../features/booking/domain/repositories/payment_repository.dart';
import '../../features/booking/domain/usecases/get_payment_methods_usecase.dart';
import '../../features/booking/domain/usecases/process_payment_usecase.dart';
import '../../features/booking/presentation/bloc/payment_bloc/payment_bloc.dart';

// Chat Feature
import '../../features/chat/data/datasources/chat_remote_data_source.dart';
import '../../features/chat/data/datasources/chat_local_data_source.dart';
import '../../features/chat/data/repositories/chat_repository_impl.dart';
import '../../features/chat/domain/repositories/chat_repository.dart';
import '../../features/chat/domain/usecases/get_chat_list_usecase.dart';
import '../../features/chat/domain/usecases/get_chat_messages_usecase.dart';
import '../../features/chat/domain/usecases/send_message_usecase.dart';
import '../../features/chat/presentation/bloc/chat_list_bloc/chat_list_bloc.dart';
import '../../features/chat/presentation/bloc/chat_bloc/chat_bloc.dart';

// Notifications Feature  
import '../../features/notifications/presentation/bloc/notifications_bloc.dart';
import '../../features/notifications/domain/usecases/get_notifications_usecase.dart';
import '../../features/notifications/domain/usecases/mark_notification_read_usecase.dart';
import '../../features/notifications/domain/usecases/get_unread_count_usecase.dart';
import '../../features/notifications/domain/entities/notification_entity.dart';
import '../../features/notifications/domain/repositories/notification_repository.dart';

// Profile Feature
import '../../features/profile/presentation/bloc/user_profile_bloc.dart';
import '../../features/profile/domain/usecases/get_user_profile_usecase.dart';
import '../../features/profile/domain/usecases/update_user_profile_usecase.dart';
import '../../features/profile/domain/entities/user_profile_entity.dart';
import '../../features/profile/domain/repositories/user_profile_repository.dart';

// Core
import '../network/api_client.dart';
import '../network/network_info.dart';
import '../services/payment_service.dart';
import '../services/location_service.dart';
import '../services/file_upload_service.dart';
import '../services/auth_service.dart';
import '../services/auth_service_impl.dart';
import '../constants/app_constants.dart';
import '../../app_config.dart';

final sl = GetIt.instance;

// Simple placeholder blocs that extend the original bloc classes
// This avoids all the use case dependency issues
class MockNotificationsBloc extends NotificationsBloc {
  MockNotificationsBloc() : super(
    getNotifications: _MockGetNotificationsUseCase(),
    markAsRead: _MockMarkNotificationAsReadUseCase(),
    getUnreadCount: _MockGetUnreadCountUseCase(),
  );
}

class MockUserProfileBloc extends UserProfileBloc {
  MockUserProfileBloc() : super(
    getUserProfile: _MockGetUserProfileUseCase(),
    updateUserProfile: _MockUpdateUserProfileUseCase(),
  );
}

// Simple internal mock use cases that implement the required interfaces
class _MockGetNotificationsUseCase implements GetNotificationsUseCase {
  @override
  Future<Either<Failure, List<NotificationEntity>>> call(String userId) async {
    // Return empty list for now
    return Right([]);
  }

  @override
  NotificationRepository get repository => _MockNotificationRepository(); // Mock repository
}

class _MockMarkNotificationAsReadUseCase implements MarkNotificationAsReadUseCase {
  @override
  Future<Either<Failure, void>> call(String notificationId) async {
    // Return success for now
    return Right(null);
  }

  @override
  NotificationRepository get repository => _MockNotificationRepository(); // Mock repository
}

class _MockGetUnreadCountUseCase implements GetUnreadCountUseCase {
  @override
  Future<Either<Failure, int>> call(String userId) async {
    // Return 0 for now
    return Right(0);
  }

  @override
  NotificationRepository get repository => _MockNotificationRepository(); // Mock repository
}

class _MockGetUserProfileUseCase implements GetUserProfileUseCase {
  @override
  Future<Either<Failure, UserProfileEntity>> call(String userId) async {
    // Return null for now
    return Left(ServerFailure('Profile not implemented'));
  }

  @override
  UserProfileRepository get repository => _MockUserProfileRepository(); // Mock repository
}

class _MockUpdateUserProfileUseCase implements UpdateUserProfileUseCase {
  @override
  Future<Either<Failure, UserProfileEntity>> call(UserProfileEntity profile) async {
    // Return same profile for now
    return Right(profile);
  }

  @override
  UserProfileRepository get repository => _MockUserProfileRepository(); // Mock repository
}

// Mock repositories
class _MockNotificationRepository implements NotificationRepository {
  @override
  Future<Either<Failure, List<NotificationEntity>>> getNotifications(String userId) {
    return Future.value(Right([]));
  }

  @override
  Future<Either<Failure, void>> markAsRead(String notificationId) {
    return Future.value(Right(null));
  }

  @override
  Future<Either<Failure, void>> markAllAsRead(String userId) {
    return Future.value(Right(null));
  }

  @override
  Future<Either<Failure, void>> deleteNotification(String notificationId) {
    return Future.value(Right(null));
  }

  @override
  Future<Either<Failure, void>> deleteAllNotifications(String userId) {
    return Future.value(Right(null));
  }

  @override
  Future<Either<Failure, int>> getUnreadCount(String userId) {
    return Future.value(Right(0));
  }

  @override
  Future<Either<Failure, void>> sendNotification({
    required String userId,
    required String title,
    required String body,
    required NotificationType type,
    Map<String, dynamic>? targetData,
    String? imageUrl,
  }) {
    return Future.value(Right(null));
  }
}

class _MockUserProfileRepository implements UserProfileRepository {
  @override
  Future<Either<Failure, UserProfileEntity>> getUserProfile(String userId) {
    return Future.value(Left(ServerFailure('Profile not implemented')));
  }

  @override
  Future<Either<Failure, UserProfileEntity>> updateProfile(UserProfileEntity profile) {
    return Future.value(Right(profile));
  }

  @override
  Future<Either<Failure, void>> changePassword(String oldPassword, String newPassword) {
    return Future.value(Right(null));
  }

  @override
  Future<Either<Failure, String>> uploadProfilePicture(String filePath) {
    return Future.value(Right('mock_profile_picture_url'));
  }

  @override
  Future<Either<Failure, void>> deleteProfilePicture() {
    return Future.value(Right(null));
  }
}

Future<void> init() async {
  // External
  final sharedPreferences = await SharedPreferences.getInstance();
  const secureStorage = FlutterSecureStorage();
  final dio = Dio(
    BaseOptions(
      baseUrl: AppConstants.baseUrl,
      connectTimeout:
          const Duration(milliseconds: AppConstants.connectionTimeout),
      receiveTimeout: const Duration(milliseconds: AppConstants.receiveTimeout),
      headers: {
        'Content-Type': 'application/json',
        'X-App-Version': AppConfig.appVersion,
      },
    ),
  );

  sl.registerLazySingleton(() => sharedPreferences);
  sl.registerLazySingleton(() => secureStorage);
  // Attach interceptor to include Firebase ID token on requests
  dio.interceptors.add(
    InterceptorsWrapper(
      onRequest: (options, handler) async {
        try {
          final auth = FirebaseAuth.instance;
          final user = auth.currentUser;
          if (user != null) {
            final idToken = await user.getIdToken();
            if (idToken != null) {
              options.headers['Authorization'] = 'Bearer $idToken';
            }
          }
        } catch (_) {
          // Silently continue without token
        }
        handler.next(options);
      },
      onError: (DioException err, handler) async {
        // If unauthorized, try to refresh the ID token once and retry
        if (err.response?.statusCode == 401) {
          try {
            final auth = FirebaseAuth.instance;
            final user = auth.currentUser;
            if (user != null) {
              final refreshed = await user.getIdToken(true);
              if (refreshed != null) {
                final requestOptions = err.requestOptions;
                requestOptions.headers['Authorization'] = 'Bearer $refreshed';
                final clone = await dio.fetch(requestOptions);
                return handler.resolve(clone);
              }
            }
          } catch (_) {}
        }
        handler.next(err);
      },
    ),
  );

  sl.registerLazySingleton(() => dio);

  // Firebase
  sl.registerLazySingleton(() => FirebaseAuth.instance);
  sl.registerLazySingleton(() => FirebaseFirestore.instance);

  // Core
  sl.registerLazySingleton<ApiClient>(() => ApiClient(sl<Dio>()));
  sl.registerLazySingleton<NetworkInfo>(() => NetworkInfoImpl());

  // Core Services
  sl.registerLazySingleton<PaymentService>(() => PaymentServiceImpl());
  sl.registerLazySingleton<LocationService>(() => LocationServiceImpl());
  sl.registerLazySingleton<FileUploadService>(() => FileUploadServiceImpl());
  sl.registerLazySingleton<AuthService>(() => AuthServiceImpl());

  // Features
  _initAuth();
  // Enable core features
  _initServices();
  _initProviders();
  _initBookings();
  // Payments are cash-only in MVP; keep DI available but unused in UI
  _initPayment();
  _initChat();
  _initNotifications();
  _initProfile();
}

void _initAuth() {
  // Data sources
  sl.registerLazySingleton<AuthFirebaseDataSource>(
    () => AuthFirebaseDataSourceImpl(
      auth: sl<FirebaseAuth>(),
      firestore: sl<FirebaseFirestore>(),
    ),
  );
  sl.registerLazySingleton<AuthLocalDataSource>(
    () => AuthLocalDataSourceImpl(
      secureStorage: sl<FlutterSecureStorage>(),
      sharedPreferences: sl<SharedPreferences>(),
    ),
  );

  // Repository
  sl.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(
      firebaseDataSource: sl<AuthFirebaseDataSource>(),
      localDataSource: sl<AuthLocalDataSource>(),
      networkInfo: sl<NetworkInfo>(),
    ),
  );

  // Use cases
  sl.registerLazySingleton(() => SignInUseCase(sl<AuthRepository>()));
  sl.registerLazySingleton(() => SignUpUseCase(sl<AuthRepository>()));
  sl.registerLazySingleton(() => SignOutUseCase(sl<AuthRepository>()));
  sl.registerLazySingleton(() => GetCurrentUserUseCase(sl<AuthRepository>()));
  sl.registerLazySingleton(() => ForgotPasswordUseCase(sl<AuthRepository>()));
  sl.registerLazySingleton(
      () => ClientSignUpUseCase(repository: sl<AuthRepository>()));

  // Blocs
  sl.registerFactory(() => AuthBloc(
        authService: sl<AuthService>(),
      ));
  sl.registerFactory(() => ClientSignUpBloc(
        clientSignUpUseCase: sl<ClientSignUpUseCase>(),
      ));
}

// ignore: unused_element
void _initServices() {
  // Data sources
  sl.registerLazySingleton<ServiceRemoteDataSource>(
    () => ServiceRemoteDataSourceImpl(apiClient: sl<ApiClient>()),
  );
  sl.registerLazySingleton<ServiceLocalDataSource>(
    () =>
        ServiceLocalDataSourceImpl(sharedPreferences: sl<SharedPreferences>()),
  );

  // Repository
  sl.registerLazySingleton<ServiceRepository>(
    () => ServiceRepositoryImpl(
      remoteDataSource: sl<ServiceRemoteDataSource>(),
      localDataSource: sl<ServiceLocalDataSource>(),
      networkInfo: sl<NetworkInfo>(),
    ),
  );

  // Use cases
  sl.registerLazySingleton(() => GetServicesUseCase(sl<ServiceRepository>()));
  sl.registerLazySingleton(
      () => GetServiceDetailsUseCase(sl<ServiceRepository>()));
  sl.registerLazySingleton(
      () => GetServicesByCategoryUseCase(sl<ServiceRepository>()));
  sl.registerLazySingleton(
      () => SearchServicesUseCase(sl<ServiceRepository>()));
  sl.registerLazySingleton(() => GetCategoriesUseCase(sl<ServiceRepository>()));

  // Blocs
  sl.registerFactory(() => ServicesBloc(
        getServices: sl<GetServicesUseCase>(),
        getServicesByCategory: sl<GetServicesByCategoryUseCase>(),
        searchServices: sl<SearchServicesUseCase>(),
        getCategories: sl<GetCategoriesUseCase>(),
      ));
  sl.registerFactory(() => ServiceDetailsBloc(
        getServiceDetails: sl<GetServiceDetailsUseCase>(),
      ));
}

// ignore: unused_element
void _initProviders() {
  // Data sources
  sl.registerLazySingleton<ProviderRemoteDataSource>(
    () => ProviderRemoteDataSourceImpl(apiClient: sl<ApiClient>()),
  );
  sl.registerLazySingleton<ProviderLocalDataSource>(
    () =>
        ProviderLocalDataSourceImpl(sharedPreferences: sl<SharedPreferences>()),
  );

  // Repository
  sl.registerLazySingleton<ProviderRepository>(
    () => ProviderRepositoryImpl(
      remoteDataSource: sl<ProviderRemoteDataSource>(),
      localDataSource: sl<ProviderLocalDataSource>(),
      networkInfo: sl<NetworkInfo>(),
    ),
  );

  // Use cases
  sl.registerLazySingleton(
      () => SearchProvidersUseCase(sl<ProviderRepository>()));
  sl.registerLazySingleton(
      () => GetProviderDetailsUseCase(sl<ProviderRepository>()));
  sl.registerLazySingleton(
      () => GetProviderReviewsUseCase(sl<ProviderRepository>()));
  sl.registerLazySingleton(
      () => GetNearbyProvidersUseCase(sl<ProviderRepository>()));
  sl.registerLazySingleton(
      () => GetFeaturedProvidersUseCase(sl<ProviderRepository>()));

  // Blocs
  sl.registerFactory(() => ProviderSearchBloc(
        searchProviders: sl<SearchProvidersUseCase>(),
        getNearbyProviders: sl<GetNearbyProvidersUseCase>(),
        getFeaturedProviders: sl<GetFeaturedProvidersUseCase>(),
      ));
  sl.registerFactory(() => ProviderDetailsBloc(
        getProviderDetails: sl<GetProviderDetailsUseCase>(),
        getProviderReviews: sl<GetProviderReviewsUseCase>(),
      ));
}

// ignore: unused_element
void _initChat() {
  // Data sources
  sl.registerLazySingleton<ChatRemoteDataSource>(
    () => ChatRemoteDataSourceImpl(),
  );
  sl.registerLazySingleton<ChatLocalDataSource>(
    () => ChatLocalDataSourceImpl(),
  );

  // Repository
  sl.registerLazySingleton<ChatRepository>(
    () => ChatRepositoryImpl(
      remoteDataSource: sl<ChatRemoteDataSource>(),
      localDataSource: sl<ChatLocalDataSource>(),
      networkInfo: sl<NetworkInfo>(),
    ),
  );

  // Use cases
  sl.registerLazySingleton(() => GetChatListUseCase(sl<ChatRepository>()));
  sl.registerLazySingleton(() => GetChatMessagesUseCase(sl<ChatRepository>()));
  sl.registerLazySingleton(() => SendMessageUseCase(sl<ChatRepository>()));

  // Blocs
  sl.registerFactory(() => ChatListBloc(
        getChatListUseCase: sl<GetChatListUseCase>(),
      ));
  sl.registerFactory(() => ChatBloc(
        getChatMessagesUseCase: sl<GetChatMessagesUseCase>(),
        sendMessageUseCase: sl<SendMessageUseCase>(),
      ));
}

// ignore: unused_element
void _initPayment() {
  // Data sources
  sl.registerLazySingleton<PaymentRemoteDataSource>(
    () => PaymentRemoteDataSourceImpl(apiClient: sl<ApiClient>()),
  );
  sl.registerLazySingleton<PaymentLocalDataSource>(
    () => PaymentLocalDataSourceImpl(),
  );

  // Repository
  sl.registerLazySingleton<PaymentRepository>(
    () => PaymentRepositoryImpl(
      remoteDataSource: sl<PaymentRemoteDataSource>(),
      localDataSource: sl<PaymentLocalDataSource>(),
      networkInfo: sl<NetworkInfo>(),
    ),
  );

  // Use cases
  sl.registerLazySingleton(
      () => GetPaymentMethodsUseCase(sl<PaymentRepository>()));
  sl.registerLazySingleton(
      () => ProcessPaymentUseCase(sl<PaymentRepository>()));

  // Blocs
  sl.registerFactory(() => PaymentBloc(
        getPaymentMethodsUseCase: sl<GetPaymentMethodsUseCase>(),
        processPaymentUseCase: sl<ProcessPaymentUseCase>(),
      ));
}

void _initNotifications() {
  // TODO: Implement full notifications feature with repository pattern
  // For now, register a simple mock notifications bloc
  sl.registerFactory<NotificationsBloc>(() => MockNotificationsBloc());
}

void _initProfile() {
  // TODO: Implement full profile feature with repository pattern
  // For now, register a simple mock profile bloc
  sl.registerFactory<UserProfileBloc>(() => MockUserProfileBloc());
}

// ignore: unused_element
void _initBookings() {
  // Data sources
  sl.registerLazySingleton<BookingRemoteDataSource>(
    () => BookingRemoteDataSourceImpl(apiClient: sl<ApiClient>()),
  );
  sl.registerLazySingleton<BookingLocalDataSource>(
    () =>
        BookingLocalDataSourceImpl(sharedPreferences: sl<SharedPreferences>()),
  );

  // Repository
  sl.registerLazySingleton<BookingRepository>(
    () => BookingRepositoryImpl(
      remoteDataSource: sl<BookingRemoteDataSource>(),
      localDataSource: sl<BookingLocalDataSource>(),
      networkInfo: sl<NetworkInfo>(),
    ),
  );

  // Use cases
  sl.registerLazySingleton(() => CreateBookingUseCase(sl<BookingRepository>()));
  sl.registerLazySingleton(
      () => GetAvailableTimeSlotsUseCase(sl<BookingRepository>()));
  sl.registerLazySingleton(
      () => GetUserBookingsUseCase(sl<BookingRepository>()));
  sl.registerLazySingleton(
      () => GetBookingDetailsUseCase(sl<BookingRepository>()));
  sl.registerLazySingleton(() => CancelBookingUseCase(sl<BookingRepository>()));

  // Blocs
  sl.registerFactory(() => CreateBookingBloc(
        createBooking: sl<CreateBookingUseCase>(),
        getAvailableTimeSlots: sl<GetAvailableTimeSlotsUseCase>(),
      ));
  sl.registerFactory(() => BookingsBloc(
        getUserBookings: sl<GetUserBookingsUseCase>(),
        getBookingDetails: sl<GetBookingDetailsUseCase>(),
        cancelBooking: sl<CancelBookingUseCase>(),
      ));
}
