class Validators {
  static const String _emailPattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
  static const String _phonePattern = r'^[0-9]{10,15}$';

  static String? validateEmail(String? email) {
    if (email == null || email.isEmpty) {
      return 'يرجى إدخال البريد الإلكتروني';
    }

    final regex = RegExp(_emailPattern);
    if (!regex.hasMatch(email)) {
      return 'يرجى إدخال بريد إلكتروني صحيح';
    }

    return null;
  }

  static String? validatePassword(String? password) {
    if (password == null || password.isEmpty) {
      return 'يرجى إدخال كلمة المرور';
    }

    if (password.length < 8) {
      return 'كلمة المرور يجب أن تكون 8 أحرف على الأقل';
    }

    return null;
  }

  static String? validateName(String? name) {
    if (name == null || name.isEmpty) {
      return 'يرجى إدخال الاسم';
    }

    if (name.length < 2) {
      return 'الاسم يجب أن يكون حرفين على الأقل';
    }

    return null;
  }

  static String? validatePhone(String? phone) {
    if (phone == null || phone.isEmpty) {
      return 'يرجى إدخال رقم الهاتف';
    }

    final regex = RegExp(_phonePattern);
    if (!regex.hasMatch(phone)) {
      return 'يرجى إدخال رقم هاتف صحيح';
    }

    return null;
  }

  static String? validateConfirmPassword(String? password, String? confirmPassword) {
    if (confirmPassword == null || confirmPassword.isEmpty) {
      return 'يرجى تأكيد كلمة المرور';
    }

    if (password != confirmPassword) {
      return 'كلمة المرور غير متطابقة';
    }

    return null;
  }

  static String? validateRequired(String? value, String fieldName) {
    if (value == null || value.isEmpty) {
      return 'يرجى إدخال $fieldName';
    }

    return null;
  }

  static String? validateAddress(String? address) {
    if (address == null || address.isEmpty) {
      return 'يرجى إدخال العنوان';
    }

    if (address.length < 10) {
      return 'يرجى إدخال عنوان مفصل أكثر';
    }

    return null;
  }

  static String? validatePrice(String? price) {
    if (price == null || price.isEmpty) {
      return 'يرجى إدخال السعر';
    }

    final numericPrice = double.tryParse(price);
    if (numericPrice == null) {
      return 'يرجى إدخال سعر صحيح';
    }

    if (numericPrice <= 0) {
      return 'السعر يجب أن يكون أكبر من صفر';
    }

    return null;
  }
}
