class AppRoutes {
  static const String home = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String profile = '/profile';
  static const String editProfile = '/profile/edit';
  static const String providerProfile = '/provider/profile';
  static const String serviceSelection = '/services';
  static const String providerSearch = '/providers';
  static const String booking = '/booking';
  static const String paymentMethods = '/payment-methods';
  static const String settings = '/settings';
}
