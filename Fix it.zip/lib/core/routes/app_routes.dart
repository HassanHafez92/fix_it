import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../di/injection_container.dart' as di;
import '../../features/auth/presentation/pages/welcome_screen.dart';
import '../../features/auth/presentation/pages/user_type_selection_screen.dart';
import '../../features/auth/presentation/pages/client_sign_up_screen.dart';
import '../../features/auth/presentation/pages/technician_sign_up_screen.dart';
import '../../features/auth/presentation/pages/sign_in_screen.dart';
import '../../features/auth/presentation/pages/sign_up_screen.dart';
import '../../features/auth/presentation/pages/forgot_password_screen.dart';
import '../../features/auth/presentation/bloc/auth_bloc.dart';
import '../../features/auth/presentation/bloc/client_sign_up/client_sign_up_bloc.dart';
import '../../features/auth/presentation/bloc/user_type_selection_bloc.dart';
import '../../features/home/presentation/pages/home_screen.dart';
import '../../features/home/presentation/pages/main_dashboard.dart';
import '../../features/services/presentation/pages/services_screen.dart';
import '../../features/services/presentation/pages/simple_service_details_screen.dart';
import '../../features/services/presentation/pages/search_screen.dart';
import '../../features/services/presentation/bloc/services_bloc.dart';
import '../../features/services/presentation/bloc/search_bloc/search_bloc.dart';
import '../../features/providers/presentation/pages/providers_screen.dart';
import '../../features/providers/presentation/pages/provider_details_screen.dart';
import '../../features/providers/presentation/bloc/provider_details_bloc.dart';
import '../../features/providers/presentation/bloc/provider_search_bloc.dart';
import '../../features/booking/presentation/pages/create_booking_screen.dart';
import '../../features/booking/presentation/pages/bookings_screen.dart';
import '../../features/booking/presentation/pages/booking_details_screen.dart';
import '../../features/booking/presentation/pages/payment_screen.dart';
import '../../features/booking/presentation/pages/add_payment_method_screen.dart';
import '../../features/booking/presentation/bloc/create_booking_bloc.dart';
import '../../features/booking/presentation/bloc/bookings_bloc.dart';
import '../../features/booking/presentation/bloc/payment_bloc/payment_bloc.dart';
import '../../features/profile/presentation/pages/profile_screen.dart';
import '../../features/profile/presentation/pages/settings_screen.dart';
import '../../features/profile/presentation/bloc/user_profile_bloc.dart';
import '../../features/profile/presentation/bloc/settings_bloc.dart';
import '../../features/notifications/presentation/pages/notifications_screen.dart';
import '../../features/notifications/presentation/bloc/notifications_bloc.dart';
import '../../features/help_support/presentation/pages/help_screen.dart';
import '../../features/chat/presentation/pages/chat_list_screen.dart';
import '../../features/chat/presentation/pages/chat_screen.dart';
import '../../features/chat/presentation/bloc/chat_list_bloc/chat_list_bloc.dart';
import '../../features/chat/presentation/bloc/chat_bloc/chat_bloc.dart';
import '../../features/services/presentation/pages/service_selection_screen.dart';
import '../../features/providers/presentation/pages/provider_search_screen.dart';
import '../../features/providers/presentation/pages/provider_availability_screen.dart';
import '../../features/booking/presentation/pages/booking_flow_screen.dart';
import '../../features/profile/presentation/pages/edit_profile_screen.dart';
import '../../features/profile/presentation/pages/change_password_screen.dart';
import '../../features/payment/presentation/pages/payment_methods_screen.dart';
import '../../features/help_support/presentation/pages/about_screen.dart';
import '../../features/help_support/presentation/pages/contact_support_screen.dart';
import '../../features/help_support/presentation/bloc/about_bloc/about_bloc.dart';
import '../../features/auth/presentation/pages/phone_sign_in_screen.dart';

class AppRoutes {
  static const String welcome = '/welcome';
  static const String userTypeSelection = '/user-type-selection';
  static const String signIn = '/sign-in';
  static const String signUp = '/sign-up';
  static const String clientSignUp = '/client-sign-up';
  static const String technicianSignUp = '/technician-sign-up';
  static const String forgotPassword = '/forgot-password';
  static const String home = '/home';
  static const String dashboard = '/dashboard';
  static const String services = '/services';
  static const String serviceDetails = '/service-details';
  static const String search = '/search';
  static const String providers = '/providers';
  static const String providerProfile = '/provider-profile';
  static const String providerDetails = '/provider-details';
  static const String createBooking = '/create-booking';
  static const String bookings = '/bookings';
  static const String bookingDetails = '/booking-details';
  static const String bookingSuccess = '/booking-success';
  static const String payment = '/payment';
  static const String addPaymentMethod = '/add-payment-method';
  static const String profile = '/profile';
  static const String editProfile = '/edit-profile';
  static const String settings = '/settings';
  static const String changePassword = '/change-password';
  static const String phoneSignIn = '/phone_sign_in';
  static const String paymentMethods = '/payment-methods';
  static const String notifications = '/notifications';
  static const String help = '/help';
  static const String about = '/about';
  static const String contactSupport = '/contact-support';
  static const String serviceSelection = '/service-selection';
  static const String providerSearchPage = '/provider-search';
  static const String providerAvailability = '/provider-availability';
  static const String bookingFlow = '/booking-flow';
  static const String chatList = '/chat-list';
  static const String chat = '/chat';

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case welcome:
        return _buildRoute(const WelcomeScreen());

      case userTypeSelection:
        return _buildRoute(
          BlocProvider(
            create: (context) => UserTypeSelectionBloc(),
            child: const UserTypeSelectionScreen(),
          ),
        );

      case clientSignUp:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<ClientSignUpBloc>(),
            child: const ClientSignUpScreen(),
          ),
        );

      case technicianSignUp:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<AuthBloc>(),
            child: const TechnicianSignUpScreen(),
          ),
        );

      case signIn:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<AuthBloc>(),
            child: const SignInScreen(),
          ),
        );

      case phoneSignIn:
        return _buildRoute(const PhoneSignInScreen());

      case signUp:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<AuthBloc>(),
            child: const SignUpScreen(),
          ),
        );

      case forgotPassword:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<AuthBloc>(),
            child: const ForgotPasswordScreen(),
          ),
        );

      case home:
        return _buildRoute(const HomeScreen());

      case dashboard:
        return _buildRoute(const MainDashboard());

      case services:
        final args = settings.arguments as Map<String, dynamic>?;
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<ServicesBloc>(),
            child: ServicesScreen(categoryId: args?['categoryId']),
          ),
        );

      case serviceDetails:
        final args = settings.arguments as Map<String, dynamic>;
        return _buildRoute(
          SimpleServiceDetailsScreen(serviceId: args['serviceId']),
        );

      case search:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<SearchBloc>(),
            child: const SearchScreen(),
          ),
        );

      case providers:
        final args = settings.arguments as Map<String, dynamic>?;
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<ProviderSearchBloc>(),
            child: ProvidersScreen(serviceCategory: args?['serviceCategory']),
          ),
        );

      case providerDetails:
        final args = settings.arguments as Map<String, dynamic>;
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<ProviderDetailsBloc>(),
            child: ProviderDetailsScreen(providerId: args['providerId']),
          ),
        );

      case providerProfile:
        final args = settings.arguments as Map<String, dynamic>;
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<ProviderDetailsBloc>(),
            child: ProviderDetailsScreen(providerId: args['providerId']),
          ),
        );

      case createBooking:
        final args = settings.arguments as Map<String, dynamic>?;
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<CreateBookingBloc>(),
            child: CreateBookingScreen(
              providerId: args?['providerId'],
              serviceId: args?['serviceId'],
            ),
          ),
        );

      case bookings:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<BookingsBloc>(),
            child: const BookingsScreen(),
          ),
        );

      case bookingDetails:
        final args = settings.arguments as Map<String, dynamic>;
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<BookingsBloc>(),
            child: BookingDetailsScreen(bookingId: args['bookingId']),
          ),
        );

      case payment:
        final args = settings.arguments as Map<String, dynamic>;
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<PaymentBloc>(),
            child: PaymentScreen(
              bookingId: args['bookingId'],
              amount: args['amount'],
            ),
          ),
        );

      case addPaymentMethod:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<PaymentBloc>(),
            child: const AddPaymentMethodScreen(),
          ),
        );

      case bookingSuccess:
        final bookingId = settings.arguments as String;
        return _buildRoute(
          Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check_circle, size: 100, color: Colors.green),
                  SizedBox(height: 20),
                  Text('Booking Successful!', style: TextStyle(fontSize: 24)),
                  Text('Booking ID: $bookingId'),
                ],
              ),
            ),
          ),
        );

      case profile:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<UserProfileBloc>(),
            child: const ProfileScreen(),
          ),
        );

      case AppRoutes.settings:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<SettingsBloc>(),
            child: const SettingsScreen(),
          ),
        );

      case notifications:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<NotificationsBloc>(),
            child: const NotificationsScreen(),
          ),
        );

      case help:
        return _buildRoute(const HelpScreen());

      case editProfile:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<UserProfileBloc>(),
            child: const EditProfileScreen(),
          ),
        );

      case changePassword:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<UserProfileBloc>(),
            child: const ChangePasswordScreen(),
          ),
        );

      case paymentMethods:
        return _buildRoute(const PaymentMethodsScreen());

      case about:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<AboutBloc>(),
            child: const AboutScreen(),
          ),
        );

      case contactSupport:
        return _buildRoute(const ContactSupportScreen());

      case serviceSelection:
        return _buildRoute(const ServiceSelectionScreen());

      case providerSearchPage:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<ProviderSearchBloc>(),
            child: const ProviderSearchScreen(),
          ),
        );

      case providerAvailability:
        final args = settings.arguments as Map<String, dynamic>;
        return _buildRoute(
          ProviderAvailabilityScreen(providerId: args['providerId']),
        );

      case bookingFlow:
        final args = settings.arguments as Map<String, dynamic>?;
        return _buildRoute(
          BookingFlowScreen(
            serviceId: args?['serviceId'],
            providerId: args?['providerId'],
          ),
        );

      case chatList:
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<ChatListBloc>(),
            child: const ChatListScreen(),
          ),
        );

      case chat:
        final args = settings.arguments as Map<String, dynamic>;
        return _buildRoute(
          BlocProvider(
            create: (context) => di.sl<ChatBloc>(),
            child: ChatScreen(
              chatId: args['chatId'],
              otherUserId: args['otherUserId'],
              otherUserName: args['otherUserName'],
            ),
          ),
        );

      default:
        return _buildRoute(
          const Scaffold(
            body: Center(
              child: Text('Page not found'),
            ),
          ),
        );
    }
  }

  static PageRoute<dynamic> _buildRoute(Widget child) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => child,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = Offset(1.0, 0.0);
        const end = Offset.zero;
        const curve = Curves.ease;

        var tween = Tween(begin: begin, end: end).chain(
          CurveTween(curve: curve),
        );

        return SlideTransition(
          position: animation.drive(tween),
          child: child,
        );
      },
      transitionDuration: const Duration(milliseconds: 300),
    );
  }
}

// class _BookingSuccessScreen extends StatelessWidget {
//   final String bookingId;

//   const _BookingSuccessScreen({required this.bookingId});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Icon(
//               Icons.check_circle,
//               size: 100,
//               color: Colors.green,
//             ),
//             const SizedBox(height: 20),
//             const Text(
//               'Booking Successful!',
//               style: TextStyle(
//                 fontSize: 24,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             const SizedBox(height: 10),
//             Text('Booking ID: $bookingId'),
//             const SizedBox(height: 30),
//             ElevatedButton(
//               onPressed: () {
//                 Navigator.pushNamedAndRemoveUntil(
//                   context,
//                   AppRoutes.bookings,
//                   (route) => false,
//                 );
//               },
//               child: const Text('View My Bookings'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
