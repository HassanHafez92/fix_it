import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'auth_service.dart';
import '../../features/profile/data/models/user_profile_model.dart';
import 'google_auth_service.dart';

class AuthServiceImpl implements AuthService {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GoogleAuthService _googleAuthService = GoogleAuthService();

  @override
  Future<UserCredential> signUpWithEmailAndPassword({
    required String email,
    required String password,
    required String name,
    required String userType,
  }) async {
    try {
      UserCredential userCredential =
          await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Create user profile document
      UserProfileModel userProfile = UserProfileModel(
        id: userCredential.user!.uid,
        fullName: name,
        email: email,
        phoneNumber: '',
        profilePictureUrl: '',
        bio: '',
        paymentMethods: const [],
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await _firestore
          .collection('users')
          .doc(userCredential.user!.uid)
          .set(userProfile.toJson());

      return userCredential;
    } catch (e) {
      throw Exception('Sign up failed: $e');
    }
  }

  @override
  Future<UserCredential> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    try {
      return await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      throw Exception('Sign in failed: $e');
    }
  }

  @override
  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }

  @override
  Future<void> resetPassword({required String email}) async {
    try {
      await _firebaseAuth.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw Exception('Password reset failed: $e');
    }
  }

  @override
  Stream<User?> get authStateChanges {
    return _firebaseAuth.authStateChanges();
  }

  @override
  Future<UserProfileModel?> getCurrentUserProfile() async {
    print('🔐 AuthService: getCurrentUserProfile called');
    final User? user = _firebaseAuth.currentUser;
    print('🔐 AuthService: Firebase current user: $user');
    print('🔐 AuthService: User ID: ${user?.uid}');
    print('🔐 AuthService: User email: ${user?.email}');
    if (user == null) {
      print('🔐 AuthService: No Firebase user, returning null');
      return null;
    }

    try {
      print(
          '🔐 AuthService: Fetching user profile from Firestore for UID: ${user.uid}');
      DocumentSnapshot doc =
          await _firestore.collection('users').doc(user.uid).get();

      print('🔐 AuthService: Firestore document exists: ${doc.exists}');
      if (doc.exists) {
        print('🔐 AuthService: Creating UserProfileModel from Firestore data');
        return UserProfileModel.fromJson(doc.data() as Map<String, dynamic>);
      }
      print('🔐 AuthService: Document does not exist, returning null');
      return null;
    } catch (e) {
      print('🔐 AuthService: Error getting user profile: $e');
      throw Exception('Failed to get user profile: $e');
    }
  }

  @override
  Future<void> updateUserProfile(UserProfileModel profile) async {
    try {
      await _firestore
          .collection('users')
          .doc(profile.id)
          .update(profile.toJson());
    } catch (e) {
      throw Exception('Failed to update user profile: $e');
    }
  }

  @override
  Future<bool> isFirstSignIn(String userId) async {
    try {
      DocumentSnapshot doc =
          await _firestore.collection('users').doc(userId).get();

      // If document doesn't exist or has no createdAt field, it's the first sign in
      return !doc.exists || !doc.data().toString().contains('createdAt');
    } catch (e) {
      throw Exception('Failed to check first sign in: $e');
    }
  }

  @override
  Future<UserCredential?> signInWithGoogle() async {
    try {
      final UserCredential? userCredential =
          await _googleAuthService.signInWithGoogle();

      if (userCredential != null && userCredential.user != null) {
        // Check if user profile exists
        UserProfileModel? existingProfile = await getCurrentUserProfile();

        // If profile doesn't exist, create a new one
        if (existingProfile == null) {
          final userProfile = UserProfileModel(
            id: userCredential.user!.uid,
            fullName: userCredential.user!.displayName ?? '',
            email: userCredential.user!.email ?? '',
            phoneNumber: '',
            profilePictureUrl: userCredential.user!.photoURL ?? '',
            bio: '',
            paymentMethods: const [],
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          );

          await _firestore
              .collection('users')
              .doc(userCredential.user!.uid)
              .set(userProfile.toJson());
        }
      }

      return userCredential;
    } catch (e) {
      throw Exception('Google sign in failed: $e');
    }
  }
}
