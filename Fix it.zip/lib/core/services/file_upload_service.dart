import 'dart:io';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

abstract class FileUploadService {
  Future<bool> requestStoragePermission();
  Future<File?> pickImageFromGallery();
  Future<File?> pickImageFromCamera();
  Future<List<File>> pickMultipleImages();
  Future<File?> pickDocument();
  Future<String?> uploadFile(File file, {String? fileName});
  Future<List<String>> uploadMultipleFiles(List<File> files);
  Future<bool> deleteFile(String fileUrl);
}

class FileUploadServiceImpl implements FileUploadService {
  final ImagePicker _imagePicker = ImagePicker();
  static const String _uploadEndpoint = 'https://your-api.com/upload';

  @override
  Future<bool> requestStoragePermission() async {
    if (Platform.isAndroid) {
      final status = await Permission.storage.request();
      return status.isGranted;
    }
    return true; // iOS doesn't require explicit permission for file access
  }

  @override
  Future<File?> pickImageFromGallery() async {
    try {
      final hasPermission = await requestStoragePermission();
      if (!hasPermission) return null;

      final XFile? pickedFile = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1920,
        maxHeight: 1080,
        imageQuality: 85,
      );

      return pickedFile != null ? File(pickedFile.path) : null;
    } catch (e) {
      return null;
    }
  }

  @override
  Future<File?> pickImageFromCamera() async {
    try {
      final cameraPermission = await Permission.camera.request();
      if (!cameraPermission.isGranted) return null;

      final XFile? pickedFile = await _imagePicker.pickImage(
        source: ImageSource.camera,
        maxWidth: 1920,
        maxHeight: 1080,
        imageQuality: 85,
      );

      return pickedFile != null ? File(pickedFile.path) : null;
    } catch (e) {
      return null;
    }
  }

  @override
  Future<List<File>> pickMultipleImages() async {
    try {
      final hasPermission = await requestStoragePermission();
      if (!hasPermission) return [];

      final List<XFile> pickedFiles = await _imagePicker.pickMultiImage(
        maxWidth: 1920,
        maxHeight: 1080,
        imageQuality: 85,
      );

      return pickedFiles.map((file) => File(file.path)).toList();
    } catch (e) {
      return [];
    }
  }

  @override
  Future<File?> pickDocument() async {
    try {
      final hasPermission = await requestStoragePermission();
      if (!hasPermission) return null;

      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'txt', 'jpg', 'jpeg', 'png'],
      );

      return result != null && result.files.single.path != null
          ? File(result.files.single.path!)
          : null;
    } catch (e) {
      return null;
    }
  }

  @override
  Future<String?> uploadFile(File file, {String? fileName}) async {
    try {
      final dio = Dio();

      String uploadFileName = fileName ?? file.path.split('/').last;

      FormData formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(
          file.path,
          filename: uploadFileName,
        ),
      });

      final response = await dio.post(
        _uploadEndpoint,
        data: formData,
        options: Options(
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        ),
        onSendProgress: (sent, total) {
          // Progress tracking if needed
          double progress = sent / total;
          print('Upload progress: ${(progress * 100).toStringAsFixed(1)}%');
        },
      );

      if (response.statusCode == 200) {
        // Assuming the API returns the file URL in the response
        return response.data['fileUrl'] ?? response.data['url'];
      }

      return null;
    } catch (e) {
      print('File upload error: $e');
      return null;
    }
  }

  @override
  Future<List<String>> uploadMultipleFiles(List<File> files) async {
    List<String> uploadedUrls = [];

    for (File file in files) {
      String? url = await uploadFile(file);
      if (url != null) {
        uploadedUrls.add(url);
      }
    }

    return uploadedUrls;
  }

  @override
  Future<bool> deleteFile(String fileUrl) async {
    try {
      final dio = Dio();

      final response = await dio.delete(
        '$_uploadEndpoint/delete',
        data: {'fileUrl': fileUrl},
      );

      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // Helper method to get cache directory for temporary files
  Future<Directory> getCacheDirectory() async {
    return await getTemporaryDirectory();
  }

  // Helper method to get app documents directory
  Future<Directory> getDocumentsDirectory() async {
    return await getApplicationDocumentsDirectory();
  }

  // Helper method to compress image before upload
  Future<File?> compressImage(File imageFile, {int quality = 85}) async {
    try {
      final directory = await getCacheDirectory();
      final compressedPath = '${directory.path}/compressed_${DateTime.now().millisecondsSinceEpoch}.jpg';

      // In a real implementation, you might use a package like flutter_image_compress
      // For now, we'll just copy the file
      return await imageFile.copy(compressedPath);
    } catch (e) {
      return null;
    }
  }
}

class FileUploadProgress {
  final String fileName;
  final double progress;
  final bool isCompleted;
  final String? error;

  FileUploadProgress({
    required this.fileName,
    required this.progress,
    required this.isCompleted,
    this.error,
  });
}
