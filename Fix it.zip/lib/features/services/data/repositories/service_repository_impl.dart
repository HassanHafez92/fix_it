import 'package:dartz/dartz.dart';

import '../../../../core/error/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/service_entity.dart';
import '../../domain/entities/category_entity.dart';
import '../../domain/repositories/service_repository.dart';
import '../datasources/service_local_data_source.dart';
import '../datasources/service_remote_data_source.dart';

class ServiceRepositoryImpl implements ServiceRepository {
  final ServiceRemoteDataSource remoteDataSource;
  final ServiceLocalDataSource localDataSource;
  final NetworkInfo networkInfo;

  ServiceRepositoryImpl({
    required this.remoteDataSource,
    required this.localDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<ServiceEntity>>> getServices() async {
    if (await networkInfo.isConnected) {
      try {
        final services = await remoteDataSource.getServices();
        await localDataSource.cacheServices(services);
        return Right(services);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      try {
        final services = await localDataSource.getCachedServices();
        return Right(services);
      } catch (e) {
        return Left(CacheFailure('No cached services available'));
      }
    }
  }

  @override
  Future<Either<Failure, List<ServiceEntity>>> getServicesByCategory(String categoryId) async {
    if (await networkInfo.isConnected) {
      try {
        final services = await remoteDataSource.getServicesByCategory(categoryId);
        return Right(services);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<Either<Failure, ServiceEntity>> getServiceDetails(String serviceId) async {
    if (await networkInfo.isConnected) {
      try {
        final service = await remoteDataSource.getServiceDetails(serviceId);
        await localDataSource.cacheServiceDetails(service);
        return Right(service);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      try {
        final service = await localDataSource.getCachedServiceDetails(serviceId);
        if (service != null) {
          return Right(service);
        } else {
          return Left(CacheFailure('No cached service details available'));
        }
      } catch (e) {
        return Left(CacheFailure('No cached service details available'));
      }
    }
  }

  @override
  Future<Either<Failure, List<ServiceEntity>>> searchServices(String query) async {
    if (await networkInfo.isConnected) {
      try {
        final services = await remoteDataSource.searchServices(query);
        return Right(services);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<Either<Failure, List<CategoryEntity>>> getCategories() async {
    if (await networkInfo.isConnected) {
      try {
        final categories = await remoteDataSource.getCategories();
        await localDataSource.cacheCategories(categories);
        return Right(categories);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      try {
        final categories = await localDataSource.getCachedCategories();
        return Right(categories);
      } catch (e) {
        return Left(CacheFailure('No cached categories available'));
      }
    }
  }
}
