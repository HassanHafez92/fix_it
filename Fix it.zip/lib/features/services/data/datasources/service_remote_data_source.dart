import '../../../../core/network/api_client.dart';
import '../models/service_model.dart';
import '../models/category_model.dart';

abstract class ServiceRemoteDataSource {
  Future<List<ServiceModel>> getServices();
  Future<List<ServiceModel>> getServicesByCategory(String categoryId);
  Future<ServiceModel> getServiceDetails(String serviceId);
  Future<List<ServiceModel>> searchServices(String query);
  Future<List<CategoryModel>> getCategories();
}

class ServiceRemoteDataSourceImpl implements ServiceRemoteDataSource {
  final ApiClient apiClient;

  ServiceRemoteDataSourceImpl({required this.apiClient});

  @override
  Future<List<ServiceModel>> getServices() async {
    return await apiClient.getServices(null);
  }

  @override
  Future<List<ServiceModel>> getServicesByCategory(String categoryId) async {
    return await apiClient.getServices(categoryId);
  }

  @override
  Future<ServiceModel> getServiceDetails(String serviceId) async {
    return await apiClient.getServiceDetails(serviceId);
  }

  @override
  Future<List<ServiceModel>> searchServices(String query) async {
    // Note: This would need to be added to the API client
    // For now, we'll use the existing getServices method
    return await apiClient.getServices(null);
  }

  @override
  Future<List<CategoryModel>> getCategories() async {
    // Note: This would need to be added to the API client
    // For now, we'll return an empty list
    return [];
  }
}
