import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'services_event.dart';
part 'services_state.dart';

class ServicesBloc extends Bloc<ServicesEvent, ServicesState> {
  ServicesBloc() : super(ServicesInitial()) {
    on<LoadServicesEvent>(_onLoadServices);
    on<SearchServicesEvent>(_onSearchServices);
    on<FilterServicesByCategoryEvent>(_onFilterServicesByCategory);
  }

  void _onLoadServices(
    LoadServicesEvent event,
    Emitter<ServicesState> emit,
  ) async {
    emit(ServicesLoading());
    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 1));

      // Mock services data
      final services = [
        {
          'id': '1',
          'name': 'Plumbing Repair',
          'description': 'Fix leaks, unclog drains, and repair pipes',
          'price': 80.0,
          'duration': 120,
          'category': 'Plumbing',
          'image': '',
        },
        {
          'id': '2',
          'name': 'Electrical Installation',
          'description': 'Install light fixtures, outlets, and switches',
          'price': 100.0,
          'duration': 90,
          'category': 'Electrical',
          'image': '',
        },
        {
          'id': '3',
          'name': 'HVAC Maintenance',
          'description': 'Regular maintenance for heating and cooling systems',
          'price': 120.0,
          'duration': 180,
          'category': 'HVAC',
          'image': '',
        },
        {
          'id': '4',
          'name': 'Carpentry Work',
          'description': 'Custom furniture, cabinets, and woodwork',
          'price': 150.0,
          'duration': 240,
          'category': 'Carpentry',
          'image': '',
        },
        {
          'id': '5',
          'name': 'Painting Services',
          'description': 'Interior and exterior painting',
          'price': 90.0,
          'duration': 180,
          'category': 'Painting',
          'image': '',
        },
        {
          'id': '6',
          'name': 'Appliance Repair',
          'description': 'Fix and maintain household appliances',
          'price': 110.0,
          'duration': 120,
          'category': 'Appliance Repair',
          'image': '',
        },
      ];

      // Get unique categories
      final categories = services
          .map((service) => service['category'] as String)
          .toSet()
          .toList();

      emit(ServicesLoaded(
        services: services,
        categories: categories,
        filteredServices: services,
        selectedCategory: null,
        searchQuery: '',
      ));
    } catch (e) {
      emit(ServicesError(message: e.toString()));
    }
  }

  void _onSearchServices(
    SearchServicesEvent event,
    Emitter<ServicesState> emit,
  ) async {
    if (state is ServicesLoaded) {
      final currentState = state as ServicesLoaded;

      emit(ServicesLoading());
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 300));

        // Filter services based on search query
        final searchQuery = event.query.toLowerCase();
        final filteredServices = currentState.services.where((service) {
          final name = service['name'].toString().toLowerCase();
          final description = service['description'].toString().toLowerCase();
          final category = service['category'].toString().toLowerCase();

          return name.contains(searchQuery) || 
                 description.contains(searchQuery) || 
                 category.contains(searchQuery);
        }).toList();

        emit(currentState.copyWith(
          filteredServices: filteredServices,
          searchQuery: event.query,
        ));
      } catch (e) {
        emit(ServicesError(message: e.toString()));
        emit(currentState);
      }
    }
  }

  void _onFilterServicesByCategory(
    FilterServicesByCategoryEvent event,
    Emitter<ServicesState> emit,
  ) async {
    if (state is ServicesLoaded) {
      final currentState = state as ServicesLoaded;

      emit(ServicesLoading());
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 300));

        // Filter services based on category
        List<Map<String, dynamic>> filteredServices;

        if (event.category == null || event.category == 'All') {
          // If no category or "All" is selected, show all services
          filteredServices = currentState.services;
        } else {
          // Filter by selected category
          filteredServices = currentState.services
              .where((service) => service['category'] == event.category)
              .toList();
        }

        // If there's a search query, apply it as well
        if (currentState.searchQuery.isNotEmpty) {
          final searchQuery = currentState.searchQuery.toLowerCase();
          filteredServices = filteredServices.where((service) {
            final name = service['name'].toString().toLowerCase();
            final description = service['description'].toString().toLowerCase();

            return name.contains(searchQuery) || description.contains(searchQuery);
          }).toList();
        }

        emit(currentState.copyWith(
          filteredServices: filteredServices,
          selectedCategory: event.category,
        ));
      } catch (e) {
        emit(ServicesError(message: e.toString()));
        emit(currentState);
      }
    }
  }
}
