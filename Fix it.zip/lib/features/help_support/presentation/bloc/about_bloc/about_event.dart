part of 'about_bloc.dart';

abstract class AboutEvent extends Equatable {
  const AboutEvent();

  @override
  List<Object> get props => [];
}

class LoadAboutInfoEvent extends AboutEvent {
  const LoadAboutInfoEvent();
}
