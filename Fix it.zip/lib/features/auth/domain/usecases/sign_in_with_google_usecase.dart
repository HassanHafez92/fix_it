import '../entities/user_entity.dart';
import '../repositories/auth_repository.dart';
import 'usecase.dart';

class SignInWithGoogleUseCase extends UseCase<UserEntity, NoParams> {
  final AuthRepository repository;

  SignInWithGoogleUseCase({required this.repository});

  @override
  Future<UserEntity> call(NoParams params) async {
    try {
      final result = await repository.signInWithGoogle();
      
      return result.fold(
        (failure) => throw Exception('Failed to sign in with Google: ${failure.message}'),
        (userEntity) => userEntity,
      );
    } catch (e) {
      throw Exception('Failed to sign in with Google: $e');
    }
  }
}
