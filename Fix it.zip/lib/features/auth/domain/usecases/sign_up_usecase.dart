import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/error/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/user_entity.dart';
import '../repositories/auth_repository.dart';

class SignUpUseCase implements UseCase<UserEntity, SignUpParams> {
  final AuthRepository repository;

  SignUpUseCase(this.repository);

  @override
  Future<Either<Failure, UserEntity>> call(SignUpParams params) async {
    return await repository.signUp(
      email: params.email,
      password: params.password,
      fullName: params.fullName,
      phoneNumber: params.phoneNumber,
      userType: params.userType,
    );
  }
}

class SignUpParams extends Equatable {
  final String email;
  final String password;
  final String fullName;
  final String phoneNumber;
  final String userType;
  final String? profession;

  const SignUpParams({
    required this.email,
    required this.password,
    required this.fullName,
    required this.phoneNumber,
    required this.userType,
    this.profession,
  });

  @override
  List<Object?> get props => [
        email,
        password,
        fullName,
        phoneNumber,
        userType,
        profession,
      ];

  @override
  String toString() {
    return 'SignUpParams(email: $email, fullName: $fullName, phoneNumber: $phoneNumber, userType: $userType, profession: $profession)';
  }
}
