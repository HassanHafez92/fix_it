import 'package:equatable/equatable.dart';

class UserEntity extends Equatable {
  final String id;
  final String email;
  final String fullName;
  final String? phoneNumber;
  final String userType; // 'client' or 'provider'
  final String? profession; // Required for providers
  final String? profilePictureUrl;
  final String? token;
  final DateTime createdAt;
  final DateTime updatedAt;

  const UserEntity({
    required this.id,
    required this.email,
    required this.fullName,
    this.phoneNumber,
    required this.userType,
    this.profession,
    this.profilePictureUrl,
    this.token,
    required this.createdAt,
    required this.updatedAt,
  });

  UserEntity copyWith({
    String? id,
    String? email,
    String? fullName,
    String? phoneNumber,
    String? userType,
    String? profession,
    String? profilePictureUrl,
    String? token,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserEntity(
      id: id ?? this.id,
      email: email ?? this.email,
      fullName: fullName ?? this.fullName,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      userType: userType ?? this.userType,
      profession: profession ?? this.profession,
      profilePictureUrl: profilePictureUrl ?? this.profilePictureUrl,
      token: token ?? this.token,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  bool get isClient => userType == 'client';
  bool get isProvider => userType == 'provider';

  @override
  List<Object?> get props => [
        id,
        email,
        fullName,
        phoneNumber,
        userType,
        profession,
        profilePictureUrl,
        token,
        createdAt,
        updatedAt,
      ];
}
