import 'package:fix_it/core/services/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/di/injection_container.dart' as di;
import '../bloc/auth_bloc.dart';
import '../pages/welcome_screen.dart';
import '../../../home/presentation/pages/main_dashboard.dart';

/// AuthWrapper handles authentication state management and navigation
///
/// This widget serves as the root authentication state manager that:
/// - Checks authentication status on app start
/// - Routes to appropriate screens based on auth state
/// - Provides authentication bloc to the widget tree
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<AuthBloc>(
      create: (context) {
        print('🔐 Creating AuthBloc...');
        try {
          final bloc = di.sl<AuthBloc>();
          print('🔐 Adding AppStartedEvent to AuthBloc...');
          bloc.add(AppStartedEvent());
          return bloc;
        } catch (e) {
          print('🔐 Error creating AuthBloc: $e');
          // Return a default bloc that will show the welcome screen
          return AuthBloc(authService: di.sl<AuthService>())..add( AppStartedEvent());
        }
      },
      child: BlocBuilder<AuthBloc, AuthState>(
        builder: (context, state) {
          print('🔐 AuthWrapper state: $state');
          
          // Handle any unexpected states
          if (state is! AuthInitial && 
              state is! AuthLoading && 
              state is! AuthAuthenticated && 
              state is! AuthUnauthenticated && 
              state is! AuthError) {
            print('🔐 Unexpected state: $state, showing welcome screen');
            return const WelcomeScreen();
          }
          
          // Show loading screen while checking authentication
          if (state is AuthInitial || state is AuthLoading) {
            print('🔐 Showing loading screen...');
            return const Scaffold(
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text(
                      'Loading...',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          // Handle navigation based on auth state
          if (state is AuthAuthenticated) {
            print('🔐 User authenticated, showing main dashboard...');
            // User is authenticated, show main dashboard
            return const MainDashboard();
          } else if (state is AuthUnauthenticated) {
            print('🔐 User not authenticated, showing welcome screen...');
            // User is not authenticated, show welcome screen
            return const WelcomeScreen();
          } else if (state is AuthError) {
            print('🔐 Auth error: ${state.message}, showing welcome screen...');
            // Show welcome screen on error
            return const WelcomeScreen();
          } else {
            print('🔐 Default case, showing welcome screen...');
            // Default case, show welcome screen
            return const WelcomeScreen();
          }
        },
      ),
    );
  }
}