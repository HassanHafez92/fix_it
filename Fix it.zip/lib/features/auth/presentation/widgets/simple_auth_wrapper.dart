import 'package:fix_it/core/services/auth_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/di/injection_container.dart' as di;
import '../bloc/auth_bloc.dart';
import '../pages/welcome_screen.dart';
import '../../../home/presentation/pages/simple_main_dashboard.dart';

/// Simple AuthWrapper that handles authentication state management and navigation
class SimpleAuthWrapper extends StatelessWidget {
  const SimpleAuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<AuthBloc>(
      create: (context) {
        try {
          final bloc = di.sl<AuthBloc>();
          bloc.add(AppStartedEvent());
          return bloc;
        } catch (e) {
          print('🔐 Error creating AuthBloc: $e');
          // Return a fallback bloc that will show the welcome screen
          return AuthBloc(authService: di.sl<AuthService>())..add( AppStartedEvent());
        }
      },
      child: const AuthWrapperContent(),
    );
  }
}

/// Handles the actual content display based on auth state
class AuthWrapperContent extends StatelessWidget {
  const AuthWrapperContent({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, state) {
        try {
          // Show loading screen while checking authentication
          if (state is AuthLoading || state is AuthInitial) {
            return const Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }
          
          // Handle navigation based on auth state
          if (state is AuthAuthenticated) {
            // User is authenticated, show main dashboard
            return const SimpleMainDashboard();
          } else if (state is AuthError) {
            // Show error message
            return Scaffold(
              body: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.error_outline, size: 64, color: Colors.red),
                    SizedBox(height: 16),
                    Text(
                      'An error occurred',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Please try again',
                      style: TextStyle(color: Colors.grey),
                    ),
                    SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        context.read<AuthBloc>().add(AppStartedEvent());
                      },
                      child: Text('Retry'),
                    ),
                  ],
                ),
              ),
            );
          } else {
            // User is not authenticated, show welcome screen
            return const WelcomeScreen();
          }
        } catch (e) {
          print('🔐 Error in AuthWrapperContent: $e');
          return const WelcomeScreen();
        }
      },
    );
  }
}
