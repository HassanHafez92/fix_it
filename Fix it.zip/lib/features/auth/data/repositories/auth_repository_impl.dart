import 'package:dartz/dartz.dart';

import '../../../../core/error/failures.dart';
import '../../../../core/network/network_info.dart';
import '../../domain/entities/user_entity.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/auth_local_data_source.dart';
import '../datasources/auth_firebase_data_source.dart';

class AuthRepositoryImpl implements AuthRepository {
  final AuthFirebaseDataSource firebaseDataSource;
  final AuthLocalDataSource localDataSource;
  final NetworkInfo networkInfo;

  AuthRepositoryImpl({
    required this.firebaseDataSource,
    required this.localDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, UserEntity>> signIn({
    required String email,
    required String password,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final user = await firebaseDataSource.signIn(
          email: email,
          password: password,
        );
        await localDataSource.cacheUserData(user);
        return Right(user);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<Either<Failure, UserEntity>> signInWithGoogle() async {
    if (await networkInfo.isConnected) {
      try {
        final user = await firebaseDataSource.signInWithGoogle();
        await localDataSource.cacheUserData(user);
        return Right(user);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<Either<Failure, UserEntity>> signUp({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
    required String userType,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final user = await firebaseDataSource.signUp(
          email: email,
          password: password,
          fullName: fullName,
          phoneNumber: phoneNumber,
          userType: userType,
        );
        await localDataSource.cacheUserData(user);
        return Right(user);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<Either<Failure, void>> signOut() async {
    if (await networkInfo.isConnected) {
      try {
        await firebaseDataSource.signOut();
        await localDataSource.clearUserData();
        await localDataSource.clearAuthToken();
        return const Right(null);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<Either<Failure, UserEntity?>> getCurrentUser() async {
    try {
      if (await networkInfo.isConnected) {
        final user = await firebaseDataSource.getCurrentUser();
        if (user != null) {
          await localDataSource.cacheUserData(user);
        }
        return Right(user);
      } else {
        final cachedUser = await localDataSource.getCachedUserData();
        return Right(cachedUser);
      }
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> forgotPassword({
    required String email,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        await firebaseDataSource.forgotPassword(email: email);
        return const Right(null);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<Either<Failure, UserEntity>> updateProfile({
    required String fullName,
    String? phoneNumber,
    String? profilePictureUrl,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        final user = await firebaseDataSource.updateProfile(
          fullName: fullName,
          phoneNumber: phoneNumber,
          profilePictureUrl: profilePictureUrl,
        );
        await localDataSource.cacheUserData(user);
        return Right(user);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<Either<Failure, void>> changePassword({
    required String newPassword,
  }) async {
    if (await networkInfo.isConnected) {
      try {
        await firebaseDataSource.changePassword(newPassword: newPassword);
        return const Right(null);
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    } else {
      return Left(NetworkFailure('No internet connection'));
    }
  }

  @override
  Future<bool> isUserLoggedIn() async {
    try {
      if (await networkInfo.isConnected) {
        final user = await firebaseDataSource.getCurrentUser();
        return user != null;
      } else {
        final cachedUser = await localDataSource.getCachedUserData();
        return cachedUser != null;
      }
    } catch (e) {
      return false;
    }
  }
}
