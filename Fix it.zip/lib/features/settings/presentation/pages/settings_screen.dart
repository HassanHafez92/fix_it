import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fix_it/core/theme/app_theme.dart';
import 'package:fix_it/core/routes/app_routes.dart';
import 'package:fix_it/features/settings/presentation/bloc/settings_bloc/settings_bloc.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  void initState() {
    super.initState();
    // Load settings when the screen initializes
    context.read<SettingsBloc>().add(LoadSettingsEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: BlocListener<SettingsBloc, SettingsState>(
        listener: (context, state) {
          if (state is SettingsUpdated) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Settings updated successfully!'),
                backgroundColor: Colors.green,
              ),
            );
          } else if (state is SettingsError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Error: ${state.message}'),
                backgroundColor: Colors.red,
              ),
            );
          }
        },
        child: BlocBuilder<SettingsBloc, SettingsState>(
          builder: (context, state) {
            if (state is SettingsLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is SettingsLoaded) {
              return _buildSettingsContent(context, state.settings);
            } else if (state is SettingsUpdating) {
              return _buildSettingsContent(context, state.settings, isLoading: true);
            } else if (state is SettingsError) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Error: ${state.message}',
                      style: const TextStyle(color: Colors.red),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        context.read<SettingsBloc>().add(LoadSettingsEvent());
                      },
                      child: const Text('Try Again'),
                    ),
                  ],
                ),
              );
            }
            return const Center(child: Text('Something went wrong'));
          },
        ),
      ),
    );
  }

  Widget _buildSettingsContent(
    BuildContext context,
    dynamic settings, {
    bool isLoading = false,
  }) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Notifications settings
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Notifications',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Push notifications toggle
                  _buildSwitchTile(
                    title: 'Push Notifications',
                    subtitle: 'Receive notifications on your device',
                    value: settings.pushNotificationsEnabled ?? true,
                    onChanged: (value) {
                      context.read<SettingsBloc>().add(
                        UpdatePushNotificationsEvent(enabled: value),
                      );
                    },
                    isLoading: isLoading,
                  ),

                  const SizedBox(height: 8),

                  // Email notifications toggle
                  _buildSwitchTile(
                    title: 'Email Notifications',
                    subtitle: 'Receive notifications via email',
                    value: settings.emailNotificationsEnabled ?? true,
                    onChanged: (value) {
                      context.read<SettingsBloc>().add(
                        UpdateEmailNotificationsEvent(enabled: value),
                      );
                    },
                    isLoading: isLoading,
                  ),

                  const SizedBox(height: 8),

                  // Booking reminders toggle
                  _buildSwitchTile(
                    title: 'Booking Reminders',
                    subtitle: 'Get reminded about upcoming bookings',
                    value: settings.bookingRemindersEnabled ?? true,
                    onChanged: (value) {
                      context.read<SettingsBloc>().add(
                        UpdateBookingRemindersEvent(enabled: value),
                      );
                    },
                    isLoading: isLoading,
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Privacy settings
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Privacy',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Location services toggle
                  _buildSwitchTile(
                    title: 'Location Services',
                    subtitle: 'Allow app to access your location',
                    value: settings.locationServicesEnabled ?? false,
                    onChanged: (value) {
                      context.read<SettingsBloc>().add(
                        UpdateLocationServicesEvent(enabled: value),
                      );
                    },
                    isLoading: isLoading,
                  ),

                  const SizedBox(height: 8),

                  // Data sharing toggle
                  _buildSwitchTile(
                    title: 'Data Sharing',
                    subtitle: 'Share anonymous usage data to improve the app',
                    value: settings.dataSharingEnabled ?? false,
                    onChanged: (value) {
                      context.read<SettingsBloc>().add(
                        UpdateDataSharingEvent(enabled: value),
                      );
                    },
                    isLoading: isLoading,
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          // App preferences
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Preferences',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Language selection
                  ListTile(
                    title: const Text('Language'),
                    subtitle: Text(settings.language ?? 'English'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: isLoading
                        ? null
                        : () {
                            _showLanguageSelectionDialog(context, settings.language ?? 'English');
                          },
                  ),

                  const Divider(height: 1),

                  // Currency selection
                  ListTile(
                    title: const Text('Currency'),
                    subtitle: Text(settings.currency ?? 'USD'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: isLoading
                        ? null
                        : () {
                            _showCurrencySelectionDialog(context, settings.currency ?? 'USD');
                          },
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 16),

          // About section
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.info),
                  title: const Text('About'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.pushNamed(context, AppRoutes.about);
                  },
                ),

                const Divider(height: 1),

                ListTile(
                  leading: const Icon(Icons.help),
                  title: const Text('Help & Support'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.pushNamed(context, AppRoutes.help);
                  },
                ),

                const Divider(height: 1),

                ListTile(
                  leading: const Icon(Icons.description),
                  title: const Text('Terms of Service'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    // Navigate to terms of service screen (not implemented yet)
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Terms of Service screen coming soon!'),
                      ),
                    );
                  },
                ),

                const Divider(height: 1),

                ListTile(
                  leading: const Icon(Icons.privacy_tip),
                  title: const Text('Privacy Policy'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    // Navigate to privacy policy screen (not implemented yet)
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Privacy Policy screen coming soon!'),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSwitchTile({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
    bool isLoading = false,
  }) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 4),

              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(width: 8),

        Switch(
          value: value,
          onChanged: isLoading ? null : onChanged,
          activeColor: AppTheme.primaryColor,
        ),
      ],
    );
  }

  void _showLanguageSelectionDialog(
    BuildContext context,
    String currentLanguage,
  ) {
    final languages = ['English', 'Arabic', 'Spanish', 'French', 'German'];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Language'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: languages.length,
            itemBuilder: (context, index) {
              final language = languages[index];
              final isSelected = language == currentLanguage;

              return ListTile(
                title: Text(language),
                trailing: isSelected
                    ? Icon(
                        Icons.check,
                        color: AppTheme.primaryColor,
                      )
                    : null,
                onTap: () {
                  Navigator.pop(context);
                  context.read<SettingsBloc>().add(
                    UpdateLanguageEvent(language: language),
                  );
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _showCurrencySelectionDialog(
    BuildContext context,
    String currentCurrency,
  ) {
    final currencies = ['USD', 'EUR', 'GBP', 'JPY', 'SAR', 'AED'];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Currency'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: currencies.length,
            itemBuilder: (context, index) {
              final currency = currencies[index];
              final isSelected = currency == currentCurrency;

              return ListTile(
                title: Text(currency),
                trailing: isSelected
                    ? Icon(
                        Icons.check,
                        color: AppTheme.primaryColor,
                      )
                    : null,
                onTap: () {
                  Navigator.pop(context);
                  context.read<SettingsBloc>().add(
                    UpdateCurrencyEvent(currency: currency),
                  );
                },
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }
}
