import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

part 'settings_event.dart';
part 'settings_state.dart';

class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  SettingsBloc() : super(SettingsInitial()) {
    on<LoadSettingsEvent>(_onLoadSettings);
    on<UpdatePushNotificationsEvent>(_onUpdatePushNotifications);
    on<UpdateEmailNotificationsEvent>(_onUpdateEmailNotifications);
    on<UpdateBookingRemindersEvent>(_onUpdateBookingReminders);
    on<UpdateLocationServicesEvent>(_onUpdateLocationServices);
    on<UpdateDataSharingEvent>(_onUpdateDataSharing);
    on<UpdateLanguageEvent>(_onUpdateLanguage);
    on<UpdateCurrencyEvent>(_onUpdateCurrency);
  }

  void _onLoadSettings(
    LoadSettingsEvent event,
    Emitter<SettingsState> emit,
  ) async {
    emit(SettingsLoading());
    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 1));

      // Mock settings data
      final settings = {
        'pushNotifications': true,
        'emailNotifications': true,
        'bookingReminders': true,
        'locationServices': true,
        'dataSharing': false,
        'language': 'English',
        'currency': 'USD',
      };

      emit(SettingsLoaded(settings: settings));
    } catch (e) {
      emit(SettingsError(message: e.toString()));
    }
  }

  void _onUpdatePushNotifications(
    UpdatePushNotificationsEvent event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is SettingsLoaded) {
      final currentState = state as SettingsLoaded;

      emit(SettingsUpdating(settings: currentState.settings));
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 500));

        // Update settings
        final updatedSettings = Map<String, dynamic>.from(currentState.settings);
        updatedSettings['pushNotifications'] = event.enabled;

        emit(SettingsLoaded(settings: updatedSettings));
        emit(SettingsUpdated());
      } catch (e) {
        emit(SettingsError(message: e.toString()));
        emit(currentState);
      }
    }
  }

  void _onUpdateEmailNotifications(
    UpdateEmailNotificationsEvent event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is SettingsLoaded) {
      final currentState = state as SettingsLoaded;

      emit(SettingsUpdating(settings: currentState.settings));
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 500));

        // Update settings
        final updatedSettings = Map<String, dynamic>.from(currentState.settings);
        updatedSettings['emailNotifications'] = event.enabled;

        emit(SettingsLoaded(settings: updatedSettings));
        emit(SettingsUpdated());
      } catch (e) {
        emit(SettingsError(message: e.toString()));
        emit(currentState);
      }
    }
  }

  void _onUpdateBookingReminders(
    UpdateBookingRemindersEvent event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is SettingsLoaded) {
      final currentState = state as SettingsLoaded;

      emit(SettingsUpdating(settings: currentState.settings));
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 500));

        // Update settings
        final updatedSettings = Map<String, dynamic>.from(currentState.settings);
        updatedSettings['bookingReminders'] = event.enabled;

        emit(SettingsLoaded(settings: updatedSettings));
        emit(SettingsUpdated());
      } catch (e) {
        emit(SettingsError(message: e.toString()));
        emit(currentState);
      }
    }
  }

  void _onUpdateLocationServices(
    UpdateLocationServicesEvent event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is SettingsLoaded) {
      final currentState = state as SettingsLoaded;

      emit(SettingsUpdating(settings: currentState.settings));
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 500));

        // Update settings
        final updatedSettings = Map<String, dynamic>.from(currentState.settings);
        updatedSettings['locationServices'] = event.enabled;

        emit(SettingsLoaded(settings: updatedSettings));
        emit(SettingsUpdated());
      } catch (e) {
        emit(SettingsError(message: e.toString()));
        emit(currentState);
      }
    }
  }

  void _onUpdateDataSharing(
    UpdateDataSharingEvent event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is SettingsLoaded) {
      final currentState = state as SettingsLoaded;

      emit(SettingsUpdating(settings: currentState.settings));
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 500));

        // Update settings
        final updatedSettings = Map<String, dynamic>.from(currentState.settings);
        updatedSettings['dataSharing'] = event.enabled;

        emit(SettingsLoaded(settings: updatedSettings));
        emit(SettingsUpdated());
      } catch (e) {
        emit(SettingsError(message: e.toString()));
        emit(currentState);
      }
    }
  }

  void _onUpdateLanguage(
    UpdateLanguageEvent event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is SettingsLoaded) {
      final currentState = state as SettingsLoaded;

      emit(SettingsUpdating(settings: currentState.settings));
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 500));

        // Update settings
        final updatedSettings = Map<String, dynamic>.from(currentState.settings);
        updatedSettings['language'] = event.language;

        emit(SettingsLoaded(settings: updatedSettings));
        emit(SettingsUpdated());
      } catch (e) {
        emit(SettingsError(message: e.toString()));
        emit(currentState);
      }
    }
  }

  void _onUpdateCurrency(
    UpdateCurrencyEvent event,
    Emitter<SettingsState> emit,
  ) async {
    if (state is SettingsLoaded) {
      final currentState = state as SettingsLoaded;

      emit(SettingsUpdating(settings: currentState.settings));
      try {
        // Simulate API call
        await Future.delayed(const Duration(milliseconds: 500));

        // Update settings
        final updatedSettings = Map<String, dynamic>.from(currentState.settings);
        updatedSettings['currency'] = event.currency;

        emit(SettingsLoaded(settings: updatedSettings));
        emit(SettingsUpdated());
      } catch (e) {
        emit(SettingsError(message: e.toString()));
        emit(currentState);
      }
    }
  }
}
