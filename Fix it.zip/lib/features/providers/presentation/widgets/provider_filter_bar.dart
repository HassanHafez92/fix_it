import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ProviderFilterBar extends StatelessWidget {
  final String? selectedCategory;
  final bool showNearbyOnly;
  final Function(String?) onCategoryChanged;
  final Function(bool) onNearbyToggle;

  const ProviderFilterBar({
    super.key,
    this.selectedCategory,
    required this.showNearbyOnly,
    required this.onCategoryChanged,
    required this.onNearbyToggle,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      color: Colors.white,
      child: Column(
        children: [
          // Category filters
          SizedBox(
            height: 50,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildCategoryChip(
                  context: context,
                  label: 'All',
                  value: null,
                  isSelected: selectedCategory == null,
                ),
                _buildCategoryChip(
                  context: context,
                  label: 'Plumbing',
                  value: 'plumbing',
                  isSelected: selectedCategory == 'plumbing',
                ),
                _buildCategoryChip(
                  context: context,
                  label: 'Electrical',
                  value: 'electrical',
                  isSelected: selectedCategory == 'electrical',
                ),
                _buildCategoryChip(
                  context: context,
                  label: 'Cleaning',
                  value: 'cleaning',
                  isSelected: selectedCategory == 'cleaning',
                ),
                _buildCategoryChip(
                  context: context,
                  label: 'Painting',
                  value: 'painting',
                  isSelected: selectedCategory == 'painting',
                ),
                _buildCategoryChip(
                  context: context,
                  label: 'Carpentry',
                  value: 'carpentry',
                  isSelected: selectedCategory == 'carpentry',
                ),
                _buildCategoryChip(
                  context: context,
                  label: 'AC Repair',
                  value: 'ac_repair',
                  isSelected: selectedCategory == 'ac_repair',
                ),
              ],
            ),
          ),

          // Quick filters
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                // Nearby toggle
                InkWell(
                  onTap: () => onNearbyToggle(!showNearbyOnly),
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: showNearbyOnly ? theme.primaryColor : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: showNearbyOnly ? theme.primaryColor : Colors.grey[400]!,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.location_on,
                          size: 16,
                          color: showNearbyOnly ? Colors.white : Colors.grey[600],
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Nearby',
                          style: GoogleFonts.cairo(
                            fontSize: 12,
                            color: showNearbyOnly ? Colors.white : Colors.grey[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(width: 12),

                // Available now filter
                InkWell(
                  onTap: () {
                    // TODO: Implement available now filter
                  },
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.grey[400]!),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.access_time,
                          size: 16,
                          color: Colors.grey[600],
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Available Now',
                          style: GoogleFonts.cairo(
                            fontSize: 12,
                            color: Colors.grey[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(width: 12),

                // Top rated filter
                InkWell(
                  onTap: () {
                    // TODO: Implement top rated filter
                  },
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Colors.grey[400]!),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.star,
                          size: 16,
                          color: Colors.grey[600],
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Top Rated',
                          style: GoogleFonts.cairo(
                            fontSize: 12,
                            color: Colors.grey[600],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          Divider(height: 1, color: Colors.grey[300]),
        ],
      ),
    );
  }

  Widget _buildCategoryChip({
    required BuildContext context,
    required String label,
    required String? value,
    required bool isSelected,
  }) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(
          label,
          style: GoogleFonts.cairo(
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: isSelected ? Colors.white : Colors.grey[700],
          ),
        ),
        selected: isSelected,
        onSelected: (selected) {
          onCategoryChanged(selected ? value : null);
        },
        selectedColor: theme.primaryColor,
        backgroundColor: Colors.grey[100],
        side: BorderSide(
          color: isSelected ? theme.primaryColor : Colors.grey[300]!,
        ),
        showCheckmark: false,
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        visualDensity: VisualDensity.compact,
      ),
    );
  }
}
