import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../domain/entities/provider_entity.dart';
import '../bloc/provider_search_bloc.dart';
import '../../../../core/di/injection_container.dart' as di;
import '../../../../core/services/location_service.dart';
import '../widgets/provider_card.dart';
import '../widgets/provider_search_bar.dart';
import '../widgets/provider_filter_bar.dart';

class ProvidersScreen extends StatefulWidget {
  final String? serviceCategory;

  const ProvidersScreen({super.key, this.serviceCategory});

  @override
  State<ProvidersScreen> createState() => _ProvidersScreenState();
}

class _ProvidersScreenState extends State<ProvidersScreen> {
  String? selectedCategory;
  bool showNearbyOnly = false;

  @override
  void initState() {
    super.initState();
    selectedCategory = widget.serviceCategory;
    _loadProviders();
  }

  void _loadProviders() {
    if (selectedCategory != null) {
      context.read<ProviderSearchBloc>().add(
            SearchProvidersEvent(serviceCategory: selectedCategory),
          );
    } else {
      context.read<ProviderSearchBloc>().add(GetFeaturedProvidersEvent());
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          selectedCategory != null
              ? '$selectedCategory Providers'
              : 'Service Providers',
          style: GoogleFonts.cairo(
            color: theme.primaryColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: theme.primaryColor),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.map, color: theme.primaryColor),
            onPressed: () {
              Navigator.pushNamed(context, '/providers_map');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          ProviderSearchBar(
            onSearch: (query) {
              context.read<ProviderSearchBloc>().add(
                    SearchProvidersEvent(
                      query: query,
                      serviceCategory: selectedCategory,
                    ),
                  );
            },
          ),

          // Filter Bar
          ProviderFilterBar(
            selectedCategory: selectedCategory,
            showNearbyOnly: showNearbyOnly,
            onCategoryChanged: (category) {
              setState(() {
                selectedCategory = category;
              });
              _loadProviders();
            },
            onNearbyToggle: (nearby) {
              setState(() {
                showNearbyOnly = nearby;
              });
              if (nearby) {
                () async {
                  final locationService = di.sl<LocationService>();
                  final position = await locationService.getCurrentLocation();
                  if (!mounted) return;
                  if (position != null) {
                    context.read<ProviderSearchBloc>().add(
                          GetNearbyProvidersEvent(
                            latitude: position.latitude,
                            longitude: position.longitude,
                            radius: 25, // km default
                          ),
                        );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Location unavailable')),
                    );
                    setState(() {
                      showNearbyOnly = false;
                    });
                  }
                }();
              } else {
                _loadProviders();
              }
            },
          ),

          // Providers List
          Expanded(
            child: BlocBuilder<ProviderSearchBloc, ProviderSearchState>(
              builder: (context, state) {
                if (state is ProviderSearchLoading) {
                  return const Center(child: CircularProgressIndicator());
                } else if (state is ProviderSearchLoaded) {
                  return _buildProvidersList(state.providers);
                } else if (state is ProviderSearchError) {
                  return _buildErrorWidget(state.message);
                } else {
                  return _buildInitialWidget();
                }
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          _showFilterBottomSheet(context);
        },
        label: const Text('Filters'),
        icon: const Icon(Icons.tune),
        backgroundColor: theme.primaryColor,
      ),
    );
  }

  Widget _buildProvidersList(List<ProviderEntity> providers) {
    if (providers.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.person_search,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'No providers found',
              style: GoogleFonts.cairo(
                fontSize: 18,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try adjusting your search or filters',
              style: GoogleFonts.cairo(
                fontSize: 14,
                color: Colors.grey[500],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: providers.length,
      itemBuilder: (context, index) {
        return ProviderCard(provider: providers[index]);
      },
    );
  }

  Widget _buildErrorWidget(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline,
            size: 64,
            color: Colors.red[400],
          ),
          const SizedBox(height: 16),
          Text(
            'Oops! Something went wrong',
            style: GoogleFonts.cairo(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            message,
            textAlign: TextAlign.center,
            style: GoogleFonts.cairo(
              fontSize: 14,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: _loadProviders,
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildInitialWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'Search for service providers',
            style: GoogleFonts.cairo(
              fontSize: 18,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Use the search bar above to find providers',
            style: GoogleFonts.cairo(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }

  void _showFilterBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Filter Providers',
              style: GoogleFonts.cairo(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),

            // Rating Filter
            Text(
              'Minimum Rating',
              style: GoogleFonts.cairo(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                for (int i = 1; i <= 5; i++)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.star, size: 16, color: Colors.amber),
                          Text(' $i+'),
                        ],
                      ),
                      selected: false, // TODO: Implement selection logic
                      onSelected: (selected) {
                        // TODO: Implement filter logic
                      },
                    ),
                  ),
              ],
            ),

            const SizedBox(height: 20),

            // Distance Filter
            Text(
              'Maximum Distance',
              style: GoogleFonts.cairo(
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (final distance in ['5 km', '10 km', '25 km', '50 km'])
                  FilterChip(
                    label: Text(distance),
                    selected: false, // TODO: Implement selection logic
                    onSelected: (selected) {
                      // TODO: Implement filter logic
                    },
                  ),
              ],
            ),

            const SizedBox(height: 32),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('Clear'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      // TODO: Apply filters
                    },
                    child: const Text('Apply'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
