import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'package:fix_it/core/theme/app_theme.dart';
import 'package:fix_it/features/providers/presentation/bloc/provider_availability_bloc/provider_availability_bloc.dart';


class ProviderAvailabilityScreen extends StatefulWidget {
  final String providerId;

  const ProviderAvailabilityScreen({
    super.key,
    required this.providerId,
  });

  @override
  State<ProviderAvailabilityScreen> createState() => _ProviderAvailabilityScreenState();
}

class _ProviderAvailabilityScreenState extends State<ProviderAvailabilityScreen> {
  CalendarFormat _calendarFormat = CalendarFormat.week;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  TimeOfDay? _selectedTime;
  Map<DateTime, List<TimeOfDay>> _availability = {};

  @override
  void initState() {
    super.initState();
    _selectedDay = _focusedDay;

    // Load provider availability when the screen initializes
    context.read<ProviderAvailabilityBloc>().add(
      LoadProviderAvailabilityEvent(providerId: widget.providerId),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Provider Availability'),
      ),
      body: BlocListener<ProviderAvailabilityBloc, ProviderAvailabilityState>(
        listener: (context, state) {
          if (state is ProviderAvailabilityError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Error: ${state.message}'),
                backgroundColor: Colors.red,
              ),
            );
          } else if (state is BookingRequested) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Booking request sent successfully!'),
                backgroundColor: Colors.green,
              ),
            );
            Navigator.pop(context);
          }
        },
        child: BlocBuilder<ProviderAvailabilityBloc, ProviderAvailabilityState>(
          builder: (context, state) {
            if (state is ProviderAvailabilityLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is ProviderAvailabilityLoaded) {
              _availability = state.availability;
              return _buildAvailabilityContent(context, state);
            } else if (state is ProviderAvailabilityError) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Error: ${state.message}',
                      style: const TextStyle(color: Colors.red),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        context.read<ProviderAvailabilityBloc>().add(
                          LoadProviderAvailabilityEvent(providerId: widget.providerId),
                        );
                      },
                      child: const Text('Try Again'),
                    ),
                  ],
                ),
              );
            }
            return const Center(child: Text('Something went wrong'));
          },
        ),
      ),
    );
  }

  Widget _buildAvailabilityContent(
    BuildContext context,
    ProviderAvailabilityLoaded state,
  ) {
    return Column(
      children: [
        // Provider info card
        Container(
          padding: const EdgeInsets.all(16.0),
          color: Colors.grey[100],
          child: Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.grey[300],
                child: const Icon(
                  Icons.person,
                  color: Colors.grey,
                  size: 30,
                ),
              ),

              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      state.providerName,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 4),

                    Row(
                      children: [
                        Icon(
                          Icons.star,
                          color: Colors.amber[500],
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${state.providerRating?.toStringAsFixed(1) ?? 'N/A'} (${state.providerTotalRatings ?? 0} reviews)',
                          style: const TextStyle(
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        // Calendar
        TableCalendar(
          firstDay: DateTime.now(),
          lastDay: DateTime.now().add(const Duration(days: 90)),
          focusedDay: _focusedDay,
          calendarFormat: _calendarFormat,
          availableCalendarFormats: const {
            CalendarFormat.week: 'Week',
            CalendarFormat.twoWeeks: '2 Weeks',
            CalendarFormat.month: 'Month',
          },
          selectedDayPredicate: (day) {
            return isSameDay(_selectedDay, day);
          },
          onDaySelected: (selectedDay, focusedDay) {
            setState(() {
              _selectedDay = selectedDay;
              _focusedDay = focusedDay;
              _selectedTime = null; // Reset selected time when day changes
            });
          },
          onFormatChanged: (format) {
            setState(() {
              _calendarFormat = format;
            });
          },
          onPageChanged: (focusedDay) {
            setState(() {
              _focusedDay = focusedDay;
            });
          },
          calendarStyle: CalendarStyle(
            todayDecoration: BoxDecoration(
              color: AppTheme.primaryColor.withValues(alpha: 0.5),
              shape: BoxShape.circle,
            ),
            selectedDecoration: BoxDecoration(
              color: AppTheme.primaryColor,
              shape: BoxShape.circle,
            ),
            markerDecoration: BoxDecoration(
              color: Colors.green,
              shape: BoxShape.circle,
            ),
          ),
          eventLoader: (day) {
            // Show markers on days with availability
            final normalizedDay = DateTime(day.year, day.month, day.day);
            return _availability[normalizedDay] ?? [];
          },
        ),

        const SizedBox(height: 16),

        // Time slots
        if (_selectedDay != null)
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Available Time Slots',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 8),

                // Time slots grid
                Expanded(
                  child: _selectedDay != null &&
                          _availability[_selectedDay!]?.isNotEmpty == true
                      ? GridView.builder(
                          padding: const EdgeInsets.all(16.0),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            childAspectRatio: 2.5,
                            crossAxisSpacing: 8,
                            mainAxisSpacing: 8,
                          ),
                          itemCount: _availability[_selectedDay!]?.length ?? 0,
                          itemBuilder: (context, index) {
                            final timeSlot = _availability[_selectedDay!]![index];
                            final isSelected = _selectedTime != null &&
                                _selectedTime!.hour == timeSlot.hour &&
                                _selectedTime!.minute == timeSlot.minute;

                            return InkWell(
                              onTap: () {
                                setState(() {
                                  _selectedTime = timeSlot;
                                });
                              },
                              borderRadius: BorderRadius.circular(8),
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? AppTheme.primaryColor
                                      : Colors.grey[200],
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Center(
                                  child: Text(
                                    DateFormat.jm().format(
                                      DateTime(
                                        _selectedDay!.year,
                                        _selectedDay!.month,
                                        _selectedDay!.day,
                                        timeSlot.hour,
                                        timeSlot.minute,
                                      ),
                                    ),
                                    style: TextStyle(
                                      color: isSelected
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: isSelected
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        )
                      : const Center(
                          child: Text(
                            'No available time slots for this day',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey,
                            ),
                          ),
                        ),
                ),

                // Book button
                if (_selectedTime != null)
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          _showBookingConfirmationDialog(context);
                        },
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          'Book Now',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          )
        else
          const Expanded(
            child: Center(
              child: Text(
                'Select a date to view available time slots',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),
            ),
          ),
      ],
    );
  }

  void _showBookingConfirmationDialog(BuildContext context) {
    if (_selectedDay == null || _selectedTime == null) return;

    final selectedDateTime = DateTime(
      _selectedDay!.year,
      _selectedDay!.month,
      _selectedDay!.day,
      _selectedTime!.hour,
      _selectedTime!.minute,
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirm Booking'),
        content: Text(
          'Are you sure you want to book this provider on '
          '${DateFormat.yMMMd().format(selectedDateTime)} at '
          '${DateFormat.jm().format(selectedDateTime)}?',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              context.read<ProviderAvailabilityBloc>().add(
                BookTimeSlotEvent(
                  providerId: widget.providerId,
                  dateTime: selectedDateTime,
                ),
              );
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }
}
