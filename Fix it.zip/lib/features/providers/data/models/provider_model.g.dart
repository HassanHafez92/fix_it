// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'provider_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ProviderModel _$ProviderModelFromJson(Map<String, dynamic> json) =>
    ProviderModel(
      id: json['id'] as String,
      name: json['name'] as String,
      email: json['email'] as String,
      phone: json['phone'] as String,
      profileImage: json['profileImage'] as String,
      bio: json['bio'] as String,
      rating: (json['rating'] as num).toDouble(),
      reviewCount: (json['reviewCount'] as num).toInt(),
      services:
          (json['services'] as List<dynamic>).map((e) => e as String).toList(),
      location: json['location'] as String,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      isVerified: json['isVerified'] as bool,
      isAvailable: json['isAvailable'] as bool,
      experienceYears: (json['experienceYears'] as num).toInt(),
      hourlyRate: (json['hourlyRate'] as num).toDouble(),
      workingHours: (json['workingHours'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      joinedDate: DateTime.parse(json['joinedDate'] as String),
    );

Map<String, dynamic> _$ProviderModelToJson(ProviderModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'email': instance.email,
      'phone': instance.phone,
      'profileImage': instance.profileImage,
      'bio': instance.bio,
      'rating': instance.rating,
      'reviewCount': instance.reviewCount,
      'services': instance.services,
      'location': instance.location,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
      'isVerified': instance.isVerified,
      'isAvailable': instance.isAvailable,
      'experienceYears': instance.experienceYears,
      'hourlyRate': instance.hourlyRate,
      'workingHours': instance.workingHours,
      'joinedDate': instance.joinedDate.toIso8601String(),
    };
