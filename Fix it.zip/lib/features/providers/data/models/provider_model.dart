import 'package:json_annotation/json_annotation.dart';

import '../../domain/entities/provider_entity.dart';

part 'provider_model.g.dart';

@JsonSerializable()
class ProviderModel extends ProviderEntity {
  const ProviderModel({
    required super.id,
    required super.name,
    required super.email,
    required super.phone,
    required super.profileImage,
    required super.bio,
    required super.rating,
    required super.reviewCount,
    required super.services,
    required super.location,
    required super.latitude,
    required super.longitude,
    required super.isVerified,
    required super.isAvailable,
    required super.experienceYears,
    required super.hourlyRate,
    required super.workingHours,
    required super.joinedDate,
  });

  factory ProviderModel.fromJson(Map<String, dynamic> json) =>
      _$ProviderModelFromJson(json);

  Map<String, dynamic> toJson() => _$ProviderModelToJson(this);

  factory ProviderModel.fromEntity(ProviderEntity entity) {
    return ProviderModel(
      id: entity.id,
      name: entity.name,
      email: entity.email,
      phone: entity.phone,
      profileImage: entity.profileImage,
      bio: entity.bio,
      rating: entity.rating,
      reviewCount: entity.reviewCount,
      services: entity.services,
      location: entity.location,
      latitude: entity.latitude,
      longitude: entity.longitude,
      isVerified: entity.isVerified,
      isAvailable: entity.isAvailable,
      experienceYears: entity.experienceYears,
      hourlyRate: entity.hourlyRate,
      workingHours: entity.workingHours,
      joinedDate: entity.joinedDate,
    );
  }
}
