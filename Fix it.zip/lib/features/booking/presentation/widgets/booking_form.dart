import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class BookingForm extends StatefulWidget {
  final String? address;
  final String? notes;
  final bool isUrgent;
  final List<String> attachments;
  final Function(String?) onAddressChanged;
  final Function(String?) onNotesChanged;
  final Function(bool) onUrgentChanged;
  final Function(List<String>) onAttachmentsChanged;
  final Function(double, double) onLocationSelected;

  const BookingForm({
    super.key,
    this.address,
    this.notes,
    required this.isUrgent,
    required this.attachments,
    required this.onAddressChanged,
    required this.onNotesChanged,
    required this.onUrgentChanged,
    required this.onAttachmentsChanged,
    required this.onLocationSelected,
  });

  @override
  State<BookingForm> createState() => _BookingFormState();
}

class _BookingFormState extends State<BookingForm> {
  final _addressController = TextEditingController();
  final _notesController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  List<File> _selectedImages = [];

  @override
  void initState() {
    super.initState();
    _addressController.text = widget.address ?? '';
    _notesController.text = widget.notes ?? '';
  }

  @override
  void dispose() {
    _addressController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Address Section
          _buildAddressSection(),

          const SizedBox(height: 24),

          // Notes Section
          _buildNotesSection(),

          const SizedBox(height: 24),

          // Urgent Service Toggle
          _buildUrgentToggle(theme),

          const SizedBox(height: 24),

          // Attachments Section
          _buildAttachmentsSection(),

          const SizedBox(height: 24),

          // Additional Info
          _buildAdditionalInfo(),
        ],
      ),
    );
  }

  Widget _buildAddressSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.location_on, color: Colors.red[600]),
                const SizedBox(width: 8),
                Text(
                  'Service Location',
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _addressController,
              decoration: InputDecoration(
                labelText: 'Enter your address',
                hintText: 'Street, City, State, ZIP',
                prefixIcon: const Icon(Icons.home),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                filled: true,
                fillColor: Colors.grey[50],
              ),
              maxLines: 2,
              onChanged: widget.onAddressChanged,
              style: GoogleFonts.cairo(),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _getCurrentLocation,
                    icon: const Icon(Icons.my_location, size: 18),
                    label: Text(
                      'Use Current Location',
                      style: GoogleFonts.cairo(fontSize: 14),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _selectOnMap,
                    icon: const Icon(Icons.map, size: 18),
                    label: Text(
                      'Select on Map',
                      style: GoogleFonts.cairo(fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotesSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.notes, color: Colors.blue[600]),
                const SizedBox(width: 8),
                Text(
                  'Additional Notes',
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _notesController,
              decoration: InputDecoration(
                labelText: 'Describe the issue or special instructions',
                hintText: 'e.g., Leaky faucet in kitchen, bring specific tools...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                filled: true,
                fillColor: Colors.grey[50],
                alignLabelWithHint: true,
              ),
              maxLines: 4,
              onChanged: widget.onNotesChanged,
              style: GoogleFonts.cairo(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUrgentToggle(ThemeData theme) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.priority_high, color: Colors.orange[600]),
                const SizedBox(width: 8),
                Text(
                  'Service Priority',
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: SwitchListTile(
                title: Text(
                  'Urgent Service',
                  style: GoogleFonts.cairo(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                subtitle: Text(
                  widget.isUrgent 
                      ? 'Priority scheduling with additional fees'
                      : 'Standard scheduling',
                  style: GoogleFonts.cairo(
                    fontSize: 12,
                    color: widget.isUrgent ? Colors.orange[700] : Colors.grey[600],
                  ),
                ),
                value: widget.isUrgent,
                onChanged: widget.onUrgentChanged,
                activeColor: Colors.orange,
                secondary: Icon(
                  widget.isUrgent ? Icons.flash_on : Icons.flash_off,
                  color: widget.isUrgent ? Colors.orange : Colors.grey[600],
                ),
              ),
            ),
            if (widget.isUrgent) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.orange[200]!),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.orange[700], size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Urgent services may have additional charges and faster response times.',
                        style: GoogleFonts.cairo(
                          fontSize: 12,
                          color: Colors.orange[700],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAttachmentsSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.attach_file, color: Colors.green[600]),
                const SizedBox(width: 8),
                Text(
                  'Attachments',
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Add photos to help describe the issue',
              style: GoogleFonts.cairo(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 16),

            // Selected Images
            if (_selectedImages.isNotEmpty) ...[
              SizedBox(
                height: 80,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _selectedImages.length,
                  itemBuilder: (context, index) {
                    return Container(
                      margin: const EdgeInsets.only(right: 8),
                      child: Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.file(
                              _selectedImages[index],
                              width: 80,
                              height: 80,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Positioned(
                            top: 4,
                            right: 4,
                            child: GestureDetector(
                              onTap: () => _removeImage(index),
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: Colors.red,
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.close,
                                  color: Colors.white,
                                  size: 16,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Add Image Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickImage(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt, size: 18),
                    label: Text(
                      'Take Photo',
                      style: GoogleFonts.cairo(fontSize: 14),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickImage(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library, size: 18),
                    label: Text(
                      'Choose Photo',
                      style: GoogleFonts.cairo(fontSize: 14),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAdditionalInfo() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.info_outline, color: Colors.blue[600]),
                const SizedBox(width: 8),
                Text(
                  'Important Information',
                  style: GoogleFonts.cairo(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildInfoItem(
              '📋',
              'Service Guarantee',
              'All services come with quality guarantee',
            ),
            _buildInfoItem(
              '💳',
              'Payment',
              'Pay securely after service completion',
            ),
            _buildInfoItem(
              '📞',
              'Communication',
              'Track your service provider in real-time',
            ),
            _buildInfoItem(
              '⭐',
              'Reviews',
              'Rate and review after service completion',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(String emoji, String title, String description) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey[800],
                  ),
                ),
                Text(
                  description,
                  style: GoogleFonts.cairo(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? image = await _picker.pickImage(source: source);
      if (image != null) {
        setState(() {
          _selectedImages.add(File(image.path));
        });
        _updateAttachments();
      }
    } catch (e) {
      // Handle error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to pick image: $e')),
      );
    }
  }

  void _removeImage(int index) {
    setState(() {
      _selectedImages.removeAt(index);
    });
    _updateAttachments();
  }

  void _updateAttachments() {
    final paths = _selectedImages.map((file) => file.path).toList();
    widget.onAttachmentsChanged(paths);
  }

  void _getCurrentLocation() {
    // TODO: Implement GPS location fetching
    // For now, use mock coordinates
    widget.onLocationSelected(37.7749, -122.4194); // San Francisco coordinates
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Current location detected')),
    );
  }

  void _selectOnMap() {
    // TODO: Implement map selection
    // For now, show placeholder
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Map selection coming soon')),
    );
  }
}
