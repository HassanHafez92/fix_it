import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../domain/entities/booking_entity.dart';
import '../../domain/usecases/get_user_bookings_usecase.dart';
import '../../domain/usecases/get_booking_details_usecase.dart';
import '../../domain/usecases/cancel_booking_usecase.dart';
import '../../../../core/usecases/usecase.dart';

part 'bookings_event.dart';
part 'bookings_state.dart';

class BookingsBloc extends Bloc<BookingsEvent, BookingsState> {
  final GetUserBookingsUseCase getUserBookings;
  final GetBookingDetailsUseCase getBookingDetails;
  final CancelBookingUseCase cancelBooking;

  BookingsBloc({
    required this.getUserBookings,
    required this.getBookingDetails,
    required this.cancelBooking,
  }) : super(BookingsInitial()) {
    on<GetUserBookingsEvent>(_onGetUserBookings);
    on<GetBookingDetailsEvent>(_onGetBookingDetails);
    on<CancelBookingEvent>(_onCancelBooking);
    on<FilterBookingsEvent>(_onFilterBookings);
  }

  Future<void> _onGetUserBookings(
    GetUserBookingsEvent event,
    Emitter<BookingsState> emit,
  ) async {
    emit(BookingsLoading());
    final result = await getUserBookings(NoParamsImpl());
    result.fold(
      (failure) => emit(BookingsError(failure.toString())),
      (bookings) => emit(BookingsLoaded(bookings)),
    );
  }

  Future<void> _onGetBookingDetails(
    GetBookingDetailsEvent event,
    Emitter<BookingsState> emit,
  ) async {
    emit(BookingDetailsLoading());
    final result = await getBookingDetails(
      GetBookingDetailsParams(bookingId: event.bookingId),
    );
    result.fold(
      (failure) => emit(BookingDetailsError(failure.toString())),
      (booking) => emit(BookingDetailsLoaded(booking)),
    );
  }

  Future<void> _onCancelBooking(
    CancelBookingEvent event,
    Emitter<BookingsState> emit,
  ) async {
    final currentState = state;
    if (currentState is BookingsLoaded) {
      emit(BookingCancelling());
      final result = await cancelBooking(CancelBookingParams(
        bookingId: event.bookingId,
        reason: event.reason,
      ));
      result.fold(
        (failure) => emit(BookingCancelError(failure.toString())),
        (_) {
          // Remove cancelled booking from list
          final updatedBookings = currentState.bookings
              .where((booking) => booking.id != event.bookingId)
              .toList();
          emit(BookingsLoaded(updatedBookings));
        },
      );
    }
  }

  Future<void> _onFilterBookings(
    FilterBookingsEvent event,
    Emitter<BookingsState> emit,
  ) async {
    final currentState = state;
    if (currentState is BookingsLoaded) {
      List<BookingEntity> filteredBookings = currentState.bookings;

      if (event.status != null) {
        filteredBookings = filteredBookings
            .where((booking) => booking.status == event.status)
            .toList();
      }

      emit(BookingsFiltered(filteredBookings, event.status));
    }
  }
}
