import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../domain/entities/time_slot_entity.dart';
import '../bloc/create_booking_bloc.dart';
import '../widgets/date_picker_widget.dart';
import '../widgets/time_slot_grid.dart';
import '../widgets/booking_form.dart';
import '../widgets/booking_summary_card.dart';
import '../../../auth/presentation/widgets/custom_button.dart';

class CreateBookingScreen extends StatefulWidget {
  final String? providerId;
  final String? serviceId;

  const CreateBookingScreen({
    super.key,
    this.providerId,
    this.serviceId,
  });

  @override
  State<CreateBookingScreen> createState() => _CreateBookingScreenState();
}

class _CreateBookingScreenState extends State<CreateBookingScreen> {
  final PageController _pageController = PageController();
  int _currentStep = 0;

  // Booking data
  DateTime? selectedDate;
  TimeSlotEntity? selectedTimeSlot;
  String? address;
  double? latitude;
  double? longitude;
  String? notes;
  bool isUrgent = false;
  List<String> attachments = [];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          'Book Service',
          style: GoogleFonts.cairo(
            color: theme.primaryColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: theme.primaryColor),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: _buildStepIndicator(),
        ),
      ),
      body: BlocListener<CreateBookingBloc, CreateBookingState>(
        listener: (context, state) {
          if (state is BookingCreated) {
            Navigator.pushReplacementNamed(
              context,
              '/booking_success',
              arguments: state.booking.id,
            );
          } else if (state is BookingCreationError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: Colors.red,
              ),
            );
          }
        },
        child: Column(
          children: [
            Expanded(
              child: PageView(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _buildDateSelectionStep(),
                  _buildTimeSelectionStep(),
                  _buildDetailsStep(),
                  _buildConfirmationStep(),
                ],
              ),
            ),
            _buildBottomNavigation(),
          ],
        ),
      ),
    );
  }

  Widget _buildStepIndicator() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        children: [
          for (int i = 0; i < 4; i++) ...[
            _buildStepCircle(i),
            if (i < 3) _buildStepLine(i),
          ],
        ],
      ),
    );
  }

  Widget _buildStepCircle(int step) {
    final theme = Theme.of(context);
    final isActive = step <= _currentStep;
    final isCompleted = step < _currentStep;

    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isActive ? theme.primaryColor : Colors.grey[300],
        border: Border.all(
          color: isActive ? theme.primaryColor : Colors.grey[300]!,
          width: 2,
        ),
      ),
      child: Center(
        child: isCompleted
            ? const Icon(Icons.check, color: Colors.white, size: 18)
            : Text(
                '${step + 1}',
                style: GoogleFonts.cairo(
                  color: isActive ? Colors.white : Colors.grey[600],
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
      ),
    );
  }

  Widget _buildStepLine(int step) {
    final theme = Theme.of(context);
    final isCompleted = step < _currentStep;

    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        color: isCompleted ? theme.primaryColor : Colors.grey[300],
      ),
    );
  }

  Widget _buildDateSelectionStep() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select Date',
            style: GoogleFonts.cairo(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Choose your preferred date for the service',
            style: GoogleFonts.cairo(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: DatePickerWidget(
              selectedDate: selectedDate,
              onDateSelected: (date) {
                setState(() {
                  selectedDate = date;
                  selectedTimeSlot = null; // Reset time slot when date changes
                });

                if (widget.providerId != null) {
                  context.read<CreateBookingBloc>().add(
                    GetAvailableTimeSlotsEvent(
                      providerId: widget.providerId!,
                      date: date,
                    ),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimeSelectionStep() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select Time',
            style: GoogleFonts.cairo(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            selectedDate != null
                ? 'Available times for ${DateFormat('MMM dd, yyyy').format(selectedDate!)}'
                : 'Please select a date first',
            style: GoogleFonts.cairo(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: BlocBuilder<CreateBookingBloc, CreateBookingState>(
              builder: (context, state) {
                if (state is TimeSlotsLoading) {
                  return const Center(child: CircularProgressIndicator());
                } else if (state is TimeSlotsLoaded) {
                  return TimeSlotGrid(
                    timeSlots: state.timeSlots,
                    selectedTimeSlot: selectedTimeSlot,
                    onTimeSlotSelected: (timeSlot) {
                      setState(() {
                        selectedTimeSlot = timeSlot;
                      });
                    },
                  );
                } else if (state is TimeSlotsError) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.error_outline, size: 64, color: Colors.red[400]),
                        const SizedBox(height: 16),
                        Text(
                          'Failed to load time slots',
                          style: GoogleFonts.cairo(fontSize: 18, color: Colors.grey[800]),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          state.message,
                          style: GoogleFonts.cairo(fontSize: 14, color: Colors.grey[600]),
                        ),
                        const SizedBox(height: 24),
                        ElevatedButton(
                          onPressed: () {
                            if (selectedDate != null && widget.providerId != null) {
                              context.read<CreateBookingBloc>().add(
                                GetAvailableTimeSlotsEvent(
                                  providerId: widget.providerId!,
                                  date: selectedDate!,
                                ),
                              );
                            }
                          },
                          child: const Text('Retry'),
                        ),
                      ],
                    ),
                  );
                }
                return Center(
                  child: Text(
                    'Select a date to view available times',
                    style: GoogleFonts.cairo(
                      fontSize: 16,
                      color: Colors.grey[600],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailsStep() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Booking Details',
            style: GoogleFonts.cairo(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Add your location and any additional details',
            style: GoogleFonts.cairo(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: BookingForm(
              address: address,
              notes: notes,
              isUrgent: isUrgent,
              attachments: attachments,
              onAddressChanged: (value) => setState(() => address = value),
              onNotesChanged: (value) => setState(() => notes = value),
              onUrgentChanged: (value) => setState(() => isUrgent = value),
              onAttachmentsChanged: (value) => setState(() => attachments = value),
              onLocationSelected: (lat, lng) {
                setState(() {
                  latitude = lat;
                  longitude = lng;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConfirmationStep() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Confirm Booking',
            style: GoogleFonts.cairo(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Review your booking details before confirming',
            style: GoogleFonts.cairo(
              fontSize: 16,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: BookingSummaryCard(
              selectedDate: selectedDate,
              selectedTimeSlot: selectedTimeSlot,
              address: address,
              notes: notes,
              isUrgent: isUrgent,
              attachments: attachments,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigation() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          if (_currentStep > 0)
            Expanded(
              child: OutlinedButton(
                onPressed: _goToPreviousStep,
                child: const Text('Back'),
              ),
            ),
          if (_currentStep > 0) const SizedBox(width: 16),
          Expanded(
            child: BlocBuilder<CreateBookingBloc, CreateBookingState>(
              builder: (context, state) {
                return CustomButton(
                  text: _currentStep == 3 ? 'Confirm Booking' : 'Next',
                  enabled: _canProceed(),
                  onPressed: _handleNextStep,
                  isLoading: state is BookingCreating,
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  bool _canProceed() {
    switch (_currentStep) {
      case 0:
        return selectedDate != null;
      case 1:
        return selectedTimeSlot != null;
      case 2:
        return address != null && address!.isNotEmpty && latitude != null && longitude != null;
      case 3:
        return true;
      default:
        return false;
    }
  }

  void _handleNextStep() {
    if (_currentStep == 3) {
      _createBooking();
    } else {
      _goToNextStep();
    }
  }

  void _goToNextStep() {
    if (_currentStep < 3) {
      setState(() {
        _currentStep++;
      });
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _goToPreviousStep() {
    if (_currentStep > 0) {
      setState(() {
        _currentStep--;
      });
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _createBooking() {
    if (widget.providerId != null &&
        widget.serviceId != null &&
        selectedDate != null &&
        selectedTimeSlot != null &&
        address != null &&
        latitude != null &&
        longitude != null) {
      context.read<CreateBookingBloc>().add(
        CreateBookingSubmittedEvent(
          providerId: widget.providerId!,
          serviceId: widget.serviceId!,
          scheduledDate: selectedDate!,
          timeSlot: '${selectedTimeSlot!.startTime} - ${selectedTimeSlot!.endTime}',
          address: address!,
          latitude: latitude!,
          longitude: longitude!,
          notes: notes,
          attachments: attachments.isNotEmpty ? attachments : null,
          isUrgent: isUrgent,
        ),
      );
    }
  }
}
