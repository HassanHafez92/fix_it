import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/routes/app_routes.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';

/// Profile tab of the main dashboard
///
/// Provides user account management:
/// - User profile information
/// - Settings and preferences
/// - Help and support access
/// - Account actions (logout, etc.)
class DashboardProfileTab extends StatefulWidget {
  const DashboardProfileTab({super.key});

  @override
  State<DashboardProfileTab> createState() => _DashboardProfileTabState();
}

class _DashboardProfileTabState extends State<DashboardProfileTab> {
  @override
  void initState() {
    super.initState();
    // Load user profile
    // TODO: Implement user profile loading
    // context.read<UserProfileBloc>().add(LoadUserProfileEvent());
    // TODO: Implement settings loading
    // context.read<SettingsBloc>().add(LoadSettingsEvent());
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: _buildAppBar(context, theme),
      body: RefreshIndicator(
        onRefresh: _onRefresh,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildProfileHeader(context, theme),
              const SizedBox(height: 24),
              _buildQuickStats(context, theme),
              const SizedBox(height: 24),
              _buildAccountSection(context, theme),
              const SizedBox(height: 24),
              _buildPreferencesSection(context, theme),
              const SizedBox(height: 24),
              _buildSupportSection(context, theme),
              const SizedBox(height: 24),
              _buildAppSection(context, theme),
              const SizedBox(height: 80), // Space for bottom navigation
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context, ThemeData theme) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      title: Text(
        'Profile',
        style: GoogleFonts.cairo(
          color: theme.primaryColor,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.edit, color: theme.primaryColor),
          onPressed: () {
            Navigator.pushNamed(context, AppRoutes.editProfile);
          },
        ),
        PopupMenuButton<String>(
          onSelected: (value) {
            switch (value) {
              case 'settings':
                Navigator.pushNamed(context, AppRoutes.settings);
                break;
              case 'help':
                Navigator.pushNamed(context, AppRoutes.help);
                break;
              case 'logout':
                _showLogoutDialog(context);
                break;
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'settings',
              child: Row(
                children: [
                  Icon(Icons.settings),
                  SizedBox(width: 8),
                  Text('Settings'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'help',
              child: Row(
                children: [
                  Icon(Icons.help),
                  SizedBox(width: 8),
                  Text('Help'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'logout',
              child: Row(
                children: [
                  Icon(Icons.logout, color: Colors.red),
                  SizedBox(width: 8),
                  Text('Logout', style: TextStyle(color: Colors.red)),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildProfileHeader(BuildContext context, ThemeData theme) {
    return BlocBuilder<AuthBloc, AuthState>(
      builder: (context, authState) {
        // TODO: Implement UserProfileBloc when available
        String userName = 'User';
        String userEmail = '';
        String userPhone = '';
        String userType = '';

        if (authState is AuthAuthenticated) {
          userName = authState.user.fullName;
          userEmail = authState.user.email;
          userPhone = authState.user.phoneNumber ?? '';
          userType = authState.user.userType == 'client'
              ? 'Client'
              : 'Service Provider';
        }

        return Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: theme.primaryColor.withOpacity(0.1),
                    child: Text(
                      userName.isNotEmpty ? userName[0].toUpperCase() : 'U',
                      style: GoogleFonts.cairo(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: theme.primaryColor,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: theme.primaryColor,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.camera_alt,
                        color: Colors.white,
                        size: 16,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                userName,
                style: GoogleFonts.cairo(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
                textAlign: TextAlign.center,
              ),
              if (userType.isNotEmpty) ...[
                const SizedBox(height: 4),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: theme.primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    userType,
                    style: GoogleFonts.cairo(
                      fontSize: 12,
                      color: theme.primaryColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              if (userEmail.isNotEmpty) ...[
                Row(
                  children: [
                    Icon(Icons.email, color: Colors.grey[600], size: 16),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        userEmail,
                        style: GoogleFonts.cairo(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
              if (userPhone.isNotEmpty) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.phone, color: Colors.grey[600], size: 16),
                    const SizedBox(width: 8),
                    Text(
                      userPhone,
                      style: GoogleFonts.cairo(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildQuickStats(BuildContext context, ThemeData theme) {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            title: 'Bookings',
            value: '12',
            icon: Icons.calendar_today,
            color: Colors.blue,
            onTap: () {
              // Navigate to bookings tab
            },
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildStatCard(
            title: 'Reviews',
            value: '4.8',
            icon: Icons.star,
            color: Colors.orange,
            onTap: () {
              // Navigate to reviews
            },
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
    VoidCallback? onTap,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Column(
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 8),
              Text(
                value,
                style: GoogleFonts.cairo(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
              Text(
                title,
                style: GoogleFonts.cairo(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAccountSection(BuildContext context, ThemeData theme) {
    return _buildSection(
      title: 'Account',
      children: [
        _buildMenuItem(
          icon: Icons.person,
          title: 'Edit Profile',
          subtitle: 'Update your personal information',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.editProfile);
          },
        ),
        _buildMenuItem(
          icon: Icons.lock,
          title: 'Change Password',
          subtitle: 'Update your account password',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.changePassword);
          },
        ),
        _buildMenuItem(
          icon: Icons.search,
          title: 'Browse Providers',
          subtitle: 'Find nearby technicians and services',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.providerSearchPage);
          },
        ),
        _buildMenuItem(
          icon: Icons.payment,
          title: 'Payment Methods',
          subtitle: 'Manage your payment options',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.paymentMethods);
          },
        ),
        _buildMenuItem(
          icon: Icons.chat_bubble_outline,
          title: 'Chat',
          subtitle: 'View your conversations',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.chatList);
          },
        ),
      ],
    );
  }

  Widget _buildPreferencesSection(BuildContext context, ThemeData theme) {
    return _buildSection(
      title: 'Preferences',
      children: [
        _buildMenuItem(
          icon: Icons.notifications,
          title: 'Notifications',
          subtitle: 'Manage notification settings',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.settings);
          },
          trailing: Switch(
            value: true,
            onChanged: (value) {
              // Handle notification toggle
            },
            activeColor: theme.primaryColor,
          ),
        ),
        _buildMenuItem(
          icon: Icons.language,
          title: 'Language',
          subtitle: 'Choose your preferred language',
          onTap: () {
            _showLanguageSelector(context);
          },
        ),
        _buildMenuItem(
          icon: Icons.dark_mode,
          title: 'Dark Mode',
          subtitle: 'Toggle dark theme',
          onTap: () {
            // Handle dark mode toggle
          },
          trailing: Switch(
            value: false,
            onChanged: (value) {
              // Handle dark mode toggle
            },
            activeColor: theme.primaryColor,
          ),
        ),
      ],
    );
  }

  Widget _buildSupportSection(BuildContext context, ThemeData theme) {
    return _buildSection(
      title: 'Support',
      children: [
        _buildMenuItem(
          icon: Icons.help,
          title: 'Help Center',
          subtitle: 'Get help and support',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.help);
          },
        ),
        _buildMenuItem(
          icon: Icons.contact_support,
          title: 'Contact Us',
          subtitle: 'Get in touch with our team',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.contactSupport);
          },
        ),
        _buildMenuItem(
          icon: Icons.star_rate,
          title: 'Rate App',
          subtitle: 'Rate us on the app store',
          onTap: () {
            _showRateAppDialog(context);
          },
        ),
      ],
    );
  }

  Widget _buildAppSection(BuildContext context, ThemeData theme) {
    return _buildSection(
      title: 'App',
      children: [
        _buildMenuItem(
          icon: Icons.info,
          title: 'About',
          subtitle: 'Learn more about Fix It',
          onTap: () {
            Navigator.pushNamed(context, AppRoutes.about);
          },
        ),
        _buildMenuItem(
          icon: Icons.privacy_tip,
          title: 'Privacy Policy',
          subtitle: 'Read our privacy policy',
          onTap: () {
            // Show privacy policy
          },
        ),
        _buildMenuItem(
          icon: Icons.description,
          title: 'Terms of Service',
          subtitle: 'Read our terms of service',
          onTap: () {
            // Show terms of service
          },
        ),
        _buildMenuItem(
          icon: Icons.logout,
          title: 'Logout',
          subtitle: 'Sign out of your account',
          onTap: () {
            _showLogoutDialog(context);
          },
          titleColor: Colors.red,
          iconColor: Colors.red,
        ),
      ],
    );
  }

  Widget _buildSection({
    required String title,
    required List<Widget> children,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.cairo(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.grey[800],
          ),
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: children,
          ),
        ),
      ],
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    Widget? trailing,
    Color? titleColor,
    Color? iconColor,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: (iconColor ?? Colors.grey[600])!.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  icon,
                  color: iconColor ?? Colors.grey[600],
                  size: 20,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.cairo(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: titleColor ?? Colors.grey[800],
                      ),
                    ),
                    Text(
                      subtitle,
                      style: GoogleFonts.cairo(
                        fontSize: 12,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
              trailing ?? Icon(Icons.chevron_right, color: Colors.grey[400]),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _onRefresh() async {
    // TODO: Implement user profile loading
    // context.read<UserProfileBloc>().add(LoadUserProfileEvent());
    // TODO: Implement settings loading
    // context.read<SettingsBloc>().add(LoadSettingsEvent());
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Logout',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Are you sure you want to logout?',
          style: GoogleFonts.cairo(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.read<AuthBloc>().add(SignOutEvent());
            },
            child: const Text('Logout', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showLanguageSelector(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Select Language',
              style: GoogleFonts.cairo(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Text('🇺🇸'),
              title: const Text('English'),
              onTap: () {
                Navigator.pop(context);
                // Handle language change
              },
            ),
            ListTile(
              leading: const Text('🇸🇦'),
              title: const Text('العربية'),
              onTap: () {
                Navigator.pop(context);
                // Handle language change
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showRateAppDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Rate Fix It',
          style: GoogleFonts.cairo(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'If you enjoy using Fix It, would you mind taking a moment to rate it? Thanks for your support!',
          style: GoogleFonts.cairo(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Not Now'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // Open app store for rating
            },
            child: const Text('Rate Now'),
          ),
        ],
      ),
    );
  }
}
