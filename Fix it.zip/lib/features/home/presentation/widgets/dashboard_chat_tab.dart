import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../core/routes/app_routes.dart';
import '../../../chat/presentation/bloc/chat_list_bloc/chat_list_bloc.dart';
import '../../../chat/presentation/widgets/chat_list_item.dart';

/// Chat tab of the main dashboard
/// 
/// Provides communication features:
/// - View all active chats with service providers
/// - Start new conversations
/// - Quick access to recent messages
/// - Real-time chat updates
class DashboardChatTab extends StatefulWidget {
  const DashboardChatTab({super.key});

  @override
  State<DashboardChatTab> createState() => _DashboardChatTabState();
}

class _DashboardChatTabState extends State<DashboardChatTab> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    // Load chat list
    context.read<ChatListBloc>().add(LoadChatListEvent());
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: _buildAppBar(context, theme),
      body: RefreshIndicator(
        onRefresh: _onRefresh,
        child: Column(
          children: [
            _buildSearchSection(context, theme),
            Expanded(
              child: _buildChatList(context, theme),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showNewChatOptions(context);
        },
        child: const Icon(Icons.add_comment),
        backgroundColor: theme.primaryColor,
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context, ThemeData theme) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      title: Text(
        'Messages',
        style: GoogleFonts.cairo(
          color: theme.primaryColor,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      actions: [
        BlocBuilder<ChatListBloc, ChatListState>(
          builder: (context, state) {
            int unreadCount = 0;
            if (state is ChatListLoaded) {
              unreadCount = state.chats.where((chat) => chat.unreadCount > 0).length;
            }

            return Stack(
              children: [
                IconButton(
                  icon: Icon(Icons.mark_email_read, color: theme.primaryColor),
                  onPressed: () {
                    _markAllAsRead();
                  },
                ),
                if (unreadCount > 0)
                  Positioned(
                    right: 8,
                    top: 8,
                    child: Container(
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      constraints: const BoxConstraints(
                        minWidth: 16,
                        minHeight: 16,
                      ),
                      child: Text(
                        unreadCount > 9 ? '9+' : unreadCount.toString(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
        PopupMenuButton<String>(
          onSelected: (value) {
            switch (value) {
              case 'archived':
                _showArchivedChats();
                break;
              case 'blocked':
                _showBlockedUsers();
                break;
              case 'settings':
                Navigator.pushNamed(context, AppRoutes.settings);
                break;
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'archived',
              child: Row(
                children: [
                  Icon(Icons.archive),
                  SizedBox(width: 8),
                  Text('Archived Chats'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'blocked',
              child: Row(
                children: [
                  Icon(Icons.block),
                  SizedBox(width: 8),
                  Text('Blocked Users'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'settings',
              child: Row(
                children: [
                  Icon(Icons.settings),
                  SizedBox(width: 8),
                  Text('Chat Settings'),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSearchSection(BuildContext context, ThemeData theme) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(16.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey[300]!),
        ),
        child: TextField(
          controller: _searchController,
          decoration: InputDecoration(
            hintText: 'Search conversations...',
            hintStyle: GoogleFonts.cairo(color: Colors.grey[600]),
            prefixIcon: Icon(Icons.search, color: Colors.grey[600]),
            suffixIcon: _searchController.text.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      _searchController.clear();
                      setState(() {
                        _searchQuery = '';
                      });
                    },
                  )
                : null,
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          ),
          onChanged: (value) {
            setState(() {
              _searchQuery = value;
            });
          },
          style: GoogleFonts.cairo(),
        ),
      ),
    );
  }

  Widget _buildChatList(BuildContext context, ThemeData theme) {
    return BlocBuilder<ChatListBloc, ChatListState>(
      builder: (context, state) {
        if (state is ChatListLoading) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }

        if (state is ChatListError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.error_outline,
                  size: 64,
                  color: Colors.grey[400],
                ),
                const SizedBox(height: 16),
                Text(
                  'Failed to load chats',
                  style: GoogleFonts.cairo(
                    fontSize: 18,
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  state.message,
                  style: GoogleFonts.cairo(
                    fontSize: 14,
                    color: Colors.grey[500],
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    context.read<ChatListBloc>().add(LoadChatListEvent());
                  },
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        if (state is ChatListLoaded) {
          var chats = state.chats;

          // Filter chats based on search query
          if (_searchQuery.isNotEmpty) {
            chats = chats.where((chat) {
              return chat.otherUserName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
                     (chat.lastMessage?.toLowerCase().contains(_searchQuery.toLowerCase()) ?? false);
            }).toList();
          }

          if (chats.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _searchQuery.isNotEmpty ? Icons.search_off : Icons.chat_bubble_outline,
                    size: 64,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _searchQuery.isNotEmpty ? 'No matching conversations' : 'No conversations yet',
                    style: GoogleFonts.cairo(
                      fontSize: 18,
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _searchQuery.isNotEmpty 
                        ? 'Try searching with different keywords'
                        : 'Start a conversation with a service provider',
                    style: GoogleFonts.cairo(
                      fontSize: 14,
                      color: Colors.grey[500],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  if (_searchQuery.isEmpty) ...[
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, AppRoutes.services);
                      },
                      child: const Text('Browse Services'),
                    ),
                  ],
                ],
              ),
            );
          }

          return Container(
            color: Colors.grey[50],
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: chats.length,
              separatorBuilder: (context, index) => Divider(
                height: 1,
                color: Colors.grey[300],
                indent: 72,
              ),
              itemBuilder: (context, index) {
                final chat = chats[index];
                return GestureDetector(
                  onLongPress: () {
                    _showChatOptions(context, chat.id);
                  },
                  child: ChatListItem(
                    chat: chat,
                    onTap: () {
                      Navigator.pushNamed(
                        context,
                        AppRoutes.chat,
                        arguments: {
                          'chatId': chat.id,
                          'participantName': chat.otherUserName,
                          'participantAvatar': chat.otherUserProfileImage,
                        },
                      );
                    },
                  ),
                );
              },
            ),
          );
        }

        return const Center(
          child: Text('Unknown state'),
        );
      },
    );
  }

  Future<void> _onRefresh() async {
    context.read<ChatListBloc>().add(LoadChatListEvent());
  }

  void _markAllAsRead() {
    // TODO: Implement mark all chats as read functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Mark all as read functionality coming soon!')),
    );
  }

  void _showNewChatOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Start New Conversation',
                style: GoogleFonts.cairo(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),
              ListTile(
                leading: const Icon(Icons.search),
                title: const Text('Find Service Provider'),
                subtitle: const Text('Search and message providers'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, AppRoutes.providers);
                },
              ),
              ListTile(
                leading: const Icon(Icons.history),
                title: const Text('From Recent Bookings'),
                subtitle: const Text('Message providers from your bookings'),
                onTap: () {
                  Navigator.pop(context);
                  _showRecentProviders(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.support_agent),
                title: const Text('Contact Support'),
                subtitle: const Text('Get help from our support team'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, AppRoutes.contactSupport);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showChatOptions(BuildContext context, String chatId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.archive),
                title: const Text('Archive Chat'),
                onTap: () {
                  Navigator.pop(context);
                  _archiveChat(chatId);
                },
              ),
              ListTile(
                leading: const Icon(Icons.volume_off),
                title: const Text('Mute Notifications'),
                onTap: () {
                  Navigator.pop(context);
                  _muteChat(chatId);
                },
              ),
              ListTile(
                leading: const Icon(Icons.block, color: Colors.red),
                title: const Text('Block User', style: TextStyle(color: Colors.red)),
                onTap: () {
                  Navigator.pop(context);
                  _blockUser(chatId);
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete, color: Colors.red),
                title: const Text('Delete Chat', style: TextStyle(color: Colors.red)),
                onTap: () {
                  Navigator.pop(context);
                  _deleteChat(chatId);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showArchivedChats() {
    // TODO: Implement archived chats view
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Archived chats feature coming soon')),
    );
  }

  void _showBlockedUsers() {
    // TODO: Implement blocked users view
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Blocked users feature coming soon')),
    );
  }

  void _showRecentProviders(BuildContext context) {
    // TODO: Implement recent providers from bookings
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Recent providers feature coming soon')),
    );
  }

  void _archiveChat(String chatId) {
    // TODO: Implement archive chat functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Archive chat functionality coming soon!')),
    );
  }

  void _muteChat(String chatId) {
    // TODO: Implement mute chat functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Mute chat functionality coming soon!')),
    );
  }

  void _blockUser(String chatId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Block User'),
        content: const Text('Are you sure you want to block this user? You won\'t receive messages from them.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // TODO: Implement block user functionality
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Block user functionality coming soon!')),
              );
            },
            child: const Text('Block', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _deleteChat(String chatId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Chat'),
        content: const Text('Are you sure you want to delete this conversation? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // TODO: Implement delete chat functionality
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Delete chat functionality coming soon!')),
              );
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
