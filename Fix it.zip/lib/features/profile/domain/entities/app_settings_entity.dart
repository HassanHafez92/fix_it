import 'package:equatable/equatable.dart';

class AppSettingsEntity extends Equatable {
  final String language;
  final String currency;
  final bool pushNotificationsEnabled;
  final bool emailNotificationsEnabled;
  final bool locationServicesEnabled;
  final bool dataSharingEnabled;
  final String theme; // 'light', 'dark', 'system'

  const AppSettingsEntity({
    this.language = 'ar',
    this.currency = 'SAR',
    this.pushNotificationsEnabled = true,
    this.emailNotificationsEnabled = true,
    this.locationServicesEnabled = true,
    this.dataSharingEnabled = false,
    this.theme = 'system',
  });

  AppSettingsEntity copyWith({
    String? language,
    String? currency,
    bool? pushNotificationsEnabled,
    bool? emailNotificationsEnabled,
    bool? locationServicesEnabled,
    bool? dataSharingEnabled,
    String? theme,
  }) {
    return AppSettingsEntity(
      language: language ?? this.language,
      currency: currency ?? this.currency,
      pushNotificationsEnabled: pushNotificationsEnabled ?? this.pushNotificationsEnabled,
      emailNotificationsEnabled: emailNotificationsEnabled ?? this.emailNotificationsEnabled,
      locationServicesEnabled: locationServicesEnabled ?? this.locationServicesEnabled,
      dataSharingEnabled: dataSharingEnabled ?? this.dataSharingEnabled,
      theme: theme ?? this.theme,
    );
  }

  @override
  List<Object> get props => [
        language,
        currency,
        pushNotificationsEnabled,
        emailNotificationsEnabled,
        locationServicesEnabled,
        dataSharingEnabled,
        theme,
      ];
}