import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'user_profile_event.dart';
part 'user_profile_state.dart';

class UserProfileBloc extends Bloc<UserProfileEvent, UserProfileState> {
  UserProfileBloc() : super(UserProfileInitial()) {
    on<LoadUserProfileEvent>(_onLoadUserProfile);
    on<UpdateUserProfileEvent>(_onUpdateUserProfile);
    on<UpdateProfilePictureEvent>(_onUpdateProfilePicture);
  }

  void _onLoadUserProfile(
    LoadUserProfileEvent event,
    Emitter<UserProfileState> emit,
  ) async {
    emit(UserProfileLoading());
    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 1));

      // Mock user profile data
      final userProfile = {
        'id': 'user123',
        'fullName': 'John Doe',
        'email': 'john.doe@example.com',
        'phoneNumber': '+1 (555) 123-4567',
        'profilePictureUrl': '',
        'bio': 'I am a professional service provider with 10 years of experience in home repairs and maintenance.',
        'address': '123 Main St, New York, NY 10001',
        'createdAt': DateTime(2020, 5, 15),
        'updatedAt': DateTime.now(),
      };

      emit(UserProfileLoaded(userProfile: userProfile));
    } catch (e) {
      emit(UserProfileError(message: e.toString()));
    }
  }

  void _onUpdateUserProfile(
    UpdateUserProfileEvent event,
    Emitter<UserProfileState> emit,
  ) async {
    if (state is UserProfileLoaded) {
      final currentState = state as UserProfileLoaded;

      emit(UserProfileUpdating());
      try {
        // Simulate API call
        await Future.delayed(const Duration(seconds: 1));

        // Create updated profile
        final updatedProfile = Map<String, dynamic>.from(currentState.userProfile);

        // Update fields if provided
        if (event.fullName != null) {
          updatedProfile['fullName'] = event.fullName;
        }
        if (event.email != null) {
          updatedProfile['email'] = event.email;
        }
        if (event.phoneNumber != null) {
          updatedProfile['phoneNumber'] = event.phoneNumber;
        }
        if (event.bio != null) {
          updatedProfile['bio'] = event.bio;
        }
        if (event.address != null) {
          updatedProfile['address'] = event.address;
        }

        // Update timestamp
        updatedProfile['updatedAt'] = DateTime.now();

        emit(UserProfileLoaded(userProfile: updatedProfile));
        emit(UserProfileUpdated());
      } catch (e) {
        emit(UserProfileError(message: e.toString()));
        emit(currentState);
      }
    }
  }

  void _onUpdateProfilePicture(
    UpdateProfilePictureEvent event,
    Emitter<UserProfileState> emit,
  ) async {
    if (state is UserProfileLoaded) {
      final currentState = state as UserProfileLoaded;

      emit(UserProfileUpdating());
      try {
        // Simulate API call
        await Future.delayed(const Duration(seconds: 1));

        // Create updated profile with new picture
        final updatedProfile = Map<String, dynamic>.from(currentState.userProfile);
        updatedProfile['profilePictureUrl'] = event.profilePictureUrl;
        updatedProfile['updatedAt'] = DateTime.now();

        emit(UserProfileLoaded(userProfile: updatedProfile));
        emit(UserProfileUpdated());
      } catch (e) {
        emit(UserProfileError(message: e.toString()));
        emit(currentState);
      }
    }
  }
}
